//+------------------------------------------------------------------+
//|                                          Gold_Confluence_EA.mq5  |
//|  XAUUSD uchun ko'p tasdiqli savdo roboti                          |
//|  Trigger : SuperTrend yo'nalishi almashishi (yopilgan sham)       |
//|  Tasdiq  : 1) Katta TF EMA200 trendi  2) RSI 50 dan yuqori/past    |
//|            3) MACD gistogramma belgisi 4) ADX kuchi (+DI/-DI)      |
//|  SL      : SuperTrend chizig'i ortida (ATR bilan cheklangan)       |
//|  TP      : RR * risk, TP1=1R da breakeven                          |
//+------------------------------------------------------------------+
#property copyright "Gold Confluence EA"
#property version   "1.00"
#property strict

#include <Trade/Trade.mqh>

input group "=== Signal ==="
input int             InpSTPeriod     = 10;        // SuperTrend ATR davri
input double          InpSTMult       = 3.0;       // SuperTrend ATR koeffitsienti
input ENUM_TIMEFRAMES InpHTF          = PERIOD_H4; // Trend uchun katta taymfreym
input int             InpHTFEMA       = 200;       // Katta TF EMA davri
input int             InpRSIPeriod    = 14;        // RSI davri
input double          InpRSIMaxBuy    = 75.0;      // BUY uchun RSI yuqori chegara (haddan oshgan)
input double          InpRSIMinSell   = 25.0;      // SELL uchun RSI quyi chegara
input int             InpMACDFast     = 12;        // MACD tez
input int             InpMACDSlow     = 26;        // MACD sekin
input int             InpMACDSignal   = 9;         // MACD signal
input int             InpADXPeriod    = 14;        // ADX davri
input double          InpADXMin       = 20.0;      // ADX minimal kuch
input int             InpMinConfirm   = 3;         // Kerakli tasdiqlar soni (0-4)
input int             InpSignalWindow = 3;         // SuperTrend almashgandan keyin necha sham ichida kirish mumkin

input group "=== Savdo ==="
input double          InpRR           = 2.0;       // Take Profit = RR * risk
input bool            InpMoveBE       = true;      // 1R da SL -> Entry
input bool            InpCloseOnFlip  = true;      // SuperTrend teskari bo'lsa yopish
input bool            InpAllowBuy     = true;      // BUY ruxsat
input bool            InpAllowSell    = true;      // SELL ruxsat
input double          InpSLMinATR     = 1.0;       // SL minimal, ATR
input double          InpSLMaxATR     = 3.0;       // SL maksimal, ATR

input group "=== Risk ==="
input double          InpRiskPct      = 1.0;       // Har savdoda risk, %
input double          InpFixedLot     = 0.0;       // Qat'iy lot (0 = risk % bo'yicha)
input double          InpMaxLot       = 1.0;       // Maksimal lot
input double          InpLotMult4     = 1.0;       // Lot koeffitsienti: 4/4 tasdiq
input double          InpLotMult3     = 1.0;       // Lot koeffitsienti: 3/4 tasdiq
double   gLotMult = 1.0;
input int             InpMaxSpreadPts = 0;         // Maksimal spred, punkt (0 = tekshirmaslik)
input double          InpMaxDailyLossPct = 3.0;    // Kunlik maksimal zarar, % (0 = o'chiq)

input group "=== Vaqt (server vaqti) ==="
input bool            InpUseSession   = true;      // Faqat faol sessiyada kirish
input int             InpStartHour    = 9;         // Boshlanish soati (server)
input int             InpEndHour      = 21;        // Tugash soati (server)
input bool            InpNoFriLate    = true;      // Juma kuni EndHour-3 dan keyin kirmaslik
input int             InpSkipStart    = -1;        // Kirmaslik oynasi boshi, server soati (-1 = o'chiq)
input int             InpSkipEnd      = -1;        // Kirmaslik oynasi oxiri, server soati

input group "=== Texnik ==="
input long            InpMagic        = 20261113;  // Magic raqam
input int             InpSlippagePts  = 50;        // Sirpanish, punkt
input bool            InpNotify       = true;      // Alert + Push

input group "=== Grafik ==="
input bool            InpDraw         = true;      // Grafikda signallar va dashboardni ko'rsatish
input int             InpHistoryBars  = 500;       // Necha sham tarixini chizish
input int             InpBoxBars      = 15;        // Signal zonasining uzunligi, sham
input color           InpTPColor      = clrDodgerBlue; // TP chiziqlari rangi
input double          InpDashScale    = 0;         // Dashboard masshtabi (0 = avto)
input color           InpBuyColor     = clrLimeGreen;  // BUY rangi
input color           InpSellColor    = clrTomato;     // SELL rangi

#define PFX "GCE_"

CTrade   trade;
int      hATR = INVALID_HANDLE, hRSI = INVALID_HANDLE, hMACD = INVALID_HANDLE;
int      hADX = INVALID_HANDLE, hHTF = INVALID_HANDLE;
datetime gLastBar = 0;
double   gDayStartBal = 0;
int      gDay = -1;
string   gInfo = "";
// last evaluation (for dashboard)
int      gD = 0, gSince = -1, gC = 0;
bool     gCH = false, gCR = false, gCM = false, gCA = false;
double   gRSI = 0, gADX = 0;
datetime gLastDash = 0;
int      gLsDir = 0;
datetime gLsTime = 0;
double   gLsEntry = 0, gLsSL = 0, gLsTP1 = 0, gLsTP2 = 0, gLsTP3 = 0;

bool DrawOK()
{
   if(!InpDraw) return false;
   if(MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_VISUAL_MODE)) return false;
   return true;
}

//+------------------------------------------------------------------+
int OnInit()
{
   hATR  = iATR(_Symbol, _Period, InpSTPeriod);
   hRSI  = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);
   hMACD = iMACD(_Symbol, _Period, InpMACDFast, InpMACDSlow, InpMACDSignal, PRICE_CLOSE);
   hADX  = iADX(_Symbol, _Period, InpADXPeriod);
   hHTF  = iMA(_Symbol, InpHTF, InpHTFEMA, 0, MODE_EMA, PRICE_CLOSE);
   if(hATR==INVALID_HANDLE || hRSI==INVALID_HANDLE || hMACD==INVALID_HANDLE ||
      hADX==INVALID_HANDLE || hHTF==INVALID_HANDLE)
   {
      Print("Indikator handle xatosi");
      return INIT_FAILED;
   }
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpSlippagePts);
   trade.SetTypeFillingBySymbol(_Symbol);
   if(DrawOK())
   {
      RemoveOscillators();
      EventSetTimer(1);
   }
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, PFX);
   if(reason == REASON_REMOVE) RemoveOscillators();
   IndicatorRelease(hATR); IndicatorRelease(hRSI); IndicatorRelease(hMACD);
   IndicatorRelease(hADX); IndicatorRelease(hHTF);
   Comment("");
   ChartRedraw();
}

void OnTimer()
{
   if(!DrawOK()) return;
   if(gLastBar == 0)
   {
      // no tick yet (weekend / just started): draw history and dashboard once
      static datetime drawnAt = 0;
      datetime b0 = iTime(_Symbol, _Period, 0);
      if(b0 > 0 && b0 != drawnAt)
      {
         DrawHistory();
         DrawDash();
         ChartRedraw();
         drawnAt = b0;
      }
      return;
   }
   DrawDash();
   DrawPosLines();
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Oscillator sub-windows                                           |
//+------------------------------------------------------------------+
bool OscExists(string prefix)
{
   int wins = (int)ChartGetInteger(0, CHART_WINDOWS_TOTAL);
   for(int w=1; w<wins; w++)
   {
      int cnt = ChartIndicatorsTotal(0, w);
      for(int i=0; i<cnt; i++)
         if(StringFind(ChartIndicatorName(0, w, i), prefix) == 0) return true;
   }
   return false;
}

void AddOscillators()
{
   int w = (int)ChartGetInteger(0, CHART_WINDOWS_TOTAL);
   if(!OscExists("RSI("))  { ChartIndicatorAdd(0, w, hRSI);  w++; }
   if(!OscExists("MACD(")) { ChartIndicatorAdd(0, w, hMACD); w++; }
   if(!OscExists("ADX("))  { ChartIndicatorAdd(0, w, hADX);  w++; }
}

void RemoveOscillators()
{
   string pre[3] = {"RSI(", "MACD(", "ADX("};
   for(int p=0; p<3; p++)
   {
      int wins = (int)ChartGetInteger(0, CHART_WINDOWS_TOTAL);
      for(int w=wins-1; w>=1; w--)
      {
         int cnt = ChartIndicatorsTotal(0, w);
         for(int i=cnt-1; i>=0; i--)
         {
            string nm = ChartIndicatorName(0, w, i);
            if(StringFind(nm, pre[p]) == 0) ChartIndicatorDelete(0, w, nm);
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Drawing helpers                                                  |
//+------------------------------------------------------------------+
double Sc()
{
   if(InpDashScale > 0) return InpDashScale;
   double s = TerminalInfoInteger(TERMINAL_SCREEN_DPI) / 96.0;
   return (s < 1.0) ? 1.0 : s;
}

void MkTrend(string nm, datetime t1, double p1, datetime t2, double p2, color c, int w, int style=STYLE_SOLID, bool ray=false)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_TREND, 0, t1, p1, t2, p2);
   else { ObjectMove(0, n, 0, t1, p1); ObjectMove(0, n, 1, t2, p2); }
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_WIDTH, w);
   ObjectSetInteger(0, n, OBJPROP_STYLE, style);
   ObjectSetInteger(0, n, OBJPROP_RAY_RIGHT, ray);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, n, OBJPROP_BACK, false);
}

void MkArrow(string nm, datetime t, double p, int code, color c, int anchor)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_ARROW, 0, t, p);
   else ObjectMove(0, n, 0, t, p);
   ObjectSetInteger(0, n, OBJPROP_ARROWCODE, code);
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_WIDTH, 3);
   ObjectSetInteger(0, n, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
}

void MkText(string nm, datetime t, double p, string txt, color c, int anchor, int fs=8)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_TEXT, 0, t, p);
   else ObjectMove(0, n, 0, t, p);
   ObjectSetString(0, n, OBJPROP_TEXT, txt);
   ObjectSetString(0, n, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
}

void DashRect(string nm, int x, int y, int w, int h, color bg, color brd)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, n, OBJPROP_COLOR, brd);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, n, OBJPROP_BACK, false);
}

void DashLabel(string nm, int x, int y, string txt, color c, int fs=9, bool bold=false)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetString(0, n, OBJPROP_TEXT, txt);
   ObjectSetString(0, n, OBJPROP_FONT, bold ? "Arial Bold" : "Arial");
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
}

//+------------------------------------------------------------------+
//| Confirmations at a given closed bar shift                         |
//+------------------------------------------------------------------+
int ConfAt(int shift, int d, bool &cH, bool &cR, bool &cM, bool &cA, double &rsi, double &adx)
{
   rsi = Buf(hRSI, 0, shift);
   double macd = Buf(hMACD, 0, shift);
   double sig  = Buf(hMACD, 1, shift);
   adx = Buf(hADX, 0, shift);
   double pdi  = Buf(hADX, 1, shift);
   double mdi  = Buf(hADX, 2, shift);
   int    hs   = iBarShift(_Symbol, InpHTF, iTime(_Symbol, _Period, shift));
   if(hs < 0) hs = 0;
   double hema = Buf(hHTF, 0, hs);
   double hcls = iClose(_Symbol, InpHTF, hs);
   if(rsi==EMPTY_VALUE || macd==EMPTY_VALUE || adx==EMPTY_VALUE || hema==EMPTY_VALUE) return -1;
   cH = (d==1) ? (hcls > hema) : (hcls < hema);
   cR = (d==1) ? (rsi > 50 && rsi < InpRSIMaxBuy) : (rsi < 50 && rsi > InpRSIMinSell);
   cM = (d==1) ? (macd - sig > 0) : (macd - sig < 0);
   cA = (adx >= InpADXMin) && ((d==1) ? (pdi > mdi) : (mdi > pdi));
   return (int)cH + (int)cR + (int)cM + (int)cA;
}

bool SessionAt(datetime tm)
{
   if(!InpUseSession) return true;
   MqlDateTime t; TimeToStruct(tm, t);
   if(t.day_of_week==0 || t.day_of_week==6) return false;
   if(t.hour < InpStartHour || t.hour >= InpEndHour) return false;
   if(InpNoFriLate && t.day_of_week==5 && t.hour >= InpEndHour-3) return false;
   return true;
}

//+------------------------------------------------------------------+
//| History: SuperTrend line + signal arrows                          |
//+------------------------------------------------------------------+
void DrawHistory()
{
   int bars = Bars(_Symbol, _Period);
   int n = MathMin(InpHistoryBars, bars - 120);
   if(n < 10) return;
   int dir[]; double line[];
   if(!CalcSuperTrend(n, dir, line)) return;
   ObjectsDeleteAll(0, PFX + "st");
   ObjectsDeleteAll(0, PFX + "sg");
   ObjectsDeleteAll(0, PFX + "bx");
   ObjectsDeleteAll(0, PFX + "lv");
   gLsDir = 0;
   datetime lastFlipSignaled = 0;
   for(int k = n-2; k >= 0; k--)
   {
      int sh = k + 1;
      datetime t1 = iTime(_Symbol, _Period, sh + 1);
      datetime t0 = iTime(_Symbol, _Period, sh);
      if(dir[k] == dir[k+1])
         MkTrend("st" + IntegerToString(k), t1, line[k+1], t0, line[k],
                 dir[k]==1 ? InpBuyColor : InpSellColor, 2);
      // bars since flip
      int j = k;
      while(j < n-1 && dir[j] == dir[j+1]) j++;
      if(j >= n-1) continue;
      int since = j - k;
      if(since >= InpSignalWindow) continue;
      datetime flipT = iTime(_Symbol, _Period, j + 1);
      if(flipT == lastFlipSignaled) continue;
      if(!SessionAt(t0)) continue;
      bool a, b, c, e; double r, x;
      int cf = ConfAt(sh, dir[k], a, b, c, e, r, x);
      if(cf < InpMinConfirm) continue;
      lastFlipSignaled = flipT;
      double atr = Buf(hATR, 0, sh);
      if(atr == EMPTY_VALUE) atr = 0;
      string id = IntegerToString((long)t0);
      int flipSh = -1;
      for(int m = k-1; m >= 0; m--) if(dir[m] != dir[k]) { flipSh = m + 1; break; }
      DrawSignalBox(id, sh, dir[k], line[k], atr, flipSh);
      if(dir[k] == 1)
      {
         double p = iLow(_Symbol, _Period, sh) - 0.3 * atr;
         MkArrow("sga" + id, t0, p, 233, InpBuyColor, ANCHOR_TOP);
         MkText("sgt" + id, t0, p - 0.6 * atr, "BUY " + IntegerToString(cf) + "/4", InpBuyColor, ANCHOR_UPPER);
      }
      else
      {
         double p = iHigh(_Symbol, _Period, sh) + 0.3 * atr;
         MkArrow("sga" + id, t0, p, 234, InpSellColor, ANCHOR_BOTTOM);
         MkText("sgt" + id, t0, p + 0.6 * atr, "SELL " + IntegerToString(cf) + "/4", InpSellColor, ANCHOR_LOWER);
      }
   }
}

//+------------------------------------------------------------------+
//| Signal levels (same formula as the robot's entry)                 |
//+------------------------------------------------------------------+
void SignalLevels(int sh, int d, double stl, double atr, double &e, double &sl, double &t1, double &t2, double &t3)
{
   e = iClose(_Symbol, _Period, sh);
   double dist = MathAbs(e - stl) + 0.1 * atr;
   dist = MathMax(dist, InpSLMinATR * atr);
   dist = MathMin(dist, InpSLMaxATR * atr);
   sl = (d == 1) ? e - dist : e + dist;
   t1 = (d == 1) ? e + dist : e - dist;
   t2 = (d == 1) ? e + InpRR * dist : e - InpRR * dist;
   t3 = (d == 1) ? e + 3.0 * dist : e - 3.0 * dist;
}

void MkRect(string nm, datetime t1, double p1, datetime t2, double p2, color c)
{
   string n = PFX + nm;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_RECTANGLE, 0, t1, p1, t2, p2);
   else { ObjectMove(0, n, 0, t1, p1); ObjectMove(0, n, 1, t2, p2); }
   ObjectSetInteger(0, n, OBJPROP_COLOR, c);
   ObjectSetInteger(0, n, OBJPROP_FILL, true);
   ObjectSetInteger(0, n, OBJPROP_BACK, true);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
}

// Every signal drawn like the SMC indicator: pastel risk/reward boxes,
// Entry / SL / TP1 / TP2 / TP3 lines with labels, OK / X marks.
// Box ends where the robot would exit: SL, BE (after TP1), TP2 or SuperTrend flip.
void DrawSignalBox(string id, int sh, int d, double stl, double atr, int flipSh)
{
   double e, sl, t1, t2, t3;
   SignalLevels(sh, d, stl, atr, e, sl, t1, t2, t3);
   datetime ts = iTime(_Symbol, _Period, sh);
   bool h1 = false, h2 = false, h3 = false, slHit = false, beHit = false, done = false;
   double curSL = sl;
   int endSh = 0;
   string why = "";
   for(int j = sh - 1; j >= 1 && !done; j--)
   {
      double hi = iHigh(_Symbol, _Period, j), lo = iLow(_Symbol, _Period, j);
      bool slTouch = (d == 1) ? (lo <= curSL) : (hi >= curSL);
      if(slTouch) { if(h1) beHit = true; else slHit = true; endSh = j; done = true; why = h1 ? "BE" : "SL"; break; }
      if(!h1 && ((d == 1) ? hi >= t1 : lo <= t1)) { h1 = true; if(InpMoveBE) curSL = e; }
      if(!h2 && ((d == 1) ? hi >= t2 : lo <= t2)) { h2 = true; endSh = j; done = true; why = "TP2"; }
      if((d == 1) ? hi >= t3 : lo <= t3) h3 = true;
      if(!done && flipSh > 0 && j == flipSh) { endSh = j; done = true; why = "FLIP"; }
   }
   datetime te = done ? iTime(_Symbol, _Period, endSh) : TimeCurrent() + PeriodSeconds() * 8;
   string b = "bx" + id + "_";
   MkRect(b + "R", ts, e, te, sl, C'255,222,222');
   MkRect(b + "G", ts, e, te, t3, C'214,244,220');
   color cB = C'0,160,90';
   MkTrend(b + "lE", ts, e,  te, e,  clrDimGray,   1);
   MkTrend(b + "lS", ts, sl, te, sl, clrOrangeRed, 2);
   MkTrend(b + "l1", ts, t1, te, t1, cB, 1, STYLE_DOT);
   MkTrend(b + "l2", ts, t2, te, t2, cB, 1, STYLE_DOT);
   MkTrend(b + "l3", ts, t3, te, t3, cB, 1);
   int dg = _Digits;
   string slTxt = "SL " + DoubleToString(sl, dg) + (slHit ? "  X" : (beHit ? "  BE" : ""));
   MkText(b + "tE", te, e,  "ENTRY " + DoubleToString(e, dg), clrDimGray, ANCHOR_LEFT, 8);
   MkText(b + "tS", te, sl, slTxt, clrOrangeRed, ANCHOR_LEFT, 8);
   MkText(b + "t1", te, t1, "TP1 " + DoubleToString(t1, dg) + (h1 ? "  OK" : ""), cB, ANCHOR_LEFT, 8);
   MkText(b + "t2", te, t2, "TP2 " + DoubleToString(t2, dg) + (h2 ? "  OK" : ""), cB, ANCHOR_LEFT, 8);
   MkText(b + "t3", te, t3, "TP3 " + DoubleToString(t3, dg) + (h3 ? "  OK" : ""), cB, ANCHOR_LEFT, 8);
   gLsDir = d; gLsTime = ts; gLsEntry = e; gLsSL = sl; gLsTP1 = t1; gLsTP2 = t2; gLsTP3 = t3;
}

//+------------------------------------------------------------------+
//| Open position: Entry / SL / TP lines                              |
//+------------------------------------------------------------------+
void DrawPosLines()
{
   long type; double open, sl, tp; ulong tk;
   if(!HasPosition(type, open, sl, tp, tk))
   {
      ObjectsDeleteAll(0, PFX + "pos");
      return;
   }
   datetime t0 = (datetime)PositionGetInteger(POSITION_TIME);
   datetime t1 = TimeCurrent() + PeriodSeconds() * 10;
   MkTrend("posE", t0, open, t1, open, clrSilver, 1, STYLE_DASH);
   MkText("posEt", t1, open, "  ENTRY " + DoubleToString(open, _Digits), clrSilver, ANCHOR_LEFT);
   if(sl > 0)
   {
      MkTrend("posS", t0, sl, t1, sl, InpSellColor, 1, STYLE_DASH);
      MkText("posSt", t1, sl, "  SL " + DoubleToString(sl, _Digits), InpSellColor, ANCHOR_LEFT);
   }
   if(tp > 0)
   {
      MkTrend("posT", t0, tp, t1, tp, InpBuyColor, 1, STYLE_DASH);
      MkText("posTt", t1, tp, "  TP " + DoubleToString(tp, _Digits), InpBuyColor, ANCHOR_LEFT);
   }
}

//+------------------------------------------------------------------+
//| Dashboard                                                        |
//+------------------------------------------------------------------+
void DrawDash()
{
   double s = Sc();
   int x0 = (int)(10 * s), y0 = (int)(25 * s);
   int w = (int)(285 * s), rh = (int)(19 * s), pad = (int)(10 * s);
   int rows = (gLsDir != 0) ? 13 : 11;
   DashRect("dbg", x0, y0, w, rh * rows + pad * 2, C'20,24,32', clrGoldenrod);
   int x = x0 + pad, y = y0 + pad;
   color cg = clrSilver;
   DashLabel("d0", x, y, "GOLD CONFLUENCE EA", clrGold, 11, true); y += (int)(rh * 1.3);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   DashLabel("d1", x, y, _Symbol + "  " + StringSubstr(EnumToString(_Period), 7) + "   Narx: " + DoubleToString(bid, _Digits), cg); y += rh;
   string sd = (gD == 1) ? "BUY" : (gD == -1 ? "SELL" : "-");
   string ss = (gSince < 0) ? "" : "  (" + IntegerToString(gSince) + " sham oldin almashgan)";
   DashLabel("d2", x, y, "SuperTrend: " + sd + ss, gD == 1 ? InpBuyColor : InpSellColor, 9, true); y += rh;
   DashLabel("d3", x, y, (gCH ? "[+] " : "[-] ") + StringSubstr(EnumToString(InpHTF), 7) + " EMA" + IntegerToString(InpHTFEMA) + " trendi", gCH ? InpBuyColor : clrGray); y += rh;
   DashLabel("d4", x, y, (gCR ? "[+] " : "[-] ") + "RSI " + DoubleToString(gRSI, 1), gCR ? InpBuyColor : clrGray); y += rh;
   DashLabel("d5", x, y, (gCM ? "[+] " : "[-] ") + "MACD impulsi", gCM ? InpBuyColor : clrGray); y += rh;
   DashLabel("d6", x, y, (gCA ? "[+] " : "[-] ") + "ADX " + DoubleToString(gADX, 1) + " (kuch >= " + DoubleToString(InpADXMin, 0) + ")", gCA ? InpBuyColor : clrGray); y += rh;
   color cc = (gC >= InpMinConfirm) ? clrGold : cg;
   DashLabel("d7", x, y, "Tasdiq: " + IntegerToString(gC) + " / 4   (kerak " + IntegerToString(InpMinConfirm) + ")", cc, 9, true); y += rh;
   if(gLsDir != 0)
   {
      DashLabel("d7b", x, y, "Oxirgi signal: " + (gLsDir == 1 ? "BUY " : "SELL ") + TimeToString(gLsTime, TIME_DATE|TIME_MINUTES), gLsDir == 1 ? InpBuyColor : InpSellColor); y += rh;
      DashLabel("d7c", x, y, "Entry " + DoubleToString(gLsEntry, _Digits) + "  SL " + DoubleToString(gLsSL, _Digits) + "  TP2 " + DoubleToString(gLsTP2, _Digits), cg); y += rh;
   }
   long type; double open, sl, tp; ulong tk;
   string st; color sc;
   if(HasPosition(type, open, sl, tp, tk))
   {
      double pr = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      st = (type == POSITION_TYPE_BUY ? "BUY OCHIQ  " : "SELL OCHIQ  ") + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2) +
           " lot   P/L: " + (pr >= 0 ? "+" : "") + DoubleToString(pr, 2) + "$";
      sc = (pr >= 0) ? InpBuyColor : InpSellColor;
   }
   else { st = "HOLAT: SIGNAL KUTILMOQDA"; sc = clrWhite; }
   DashLabel("d8", x, y, st, sc, 10, true); y += (int)(rh * 1.2);
   bool sess = SessionAt(TimeCurrent());
   DashLabel("d9", x, y, "Sessiya: " + (sess ? "faol" : "yopiq (kirish yo'q)") + "   Server: " + TimeToString(TimeCurrent(), TIME_MINUTES), sess ? cg : clrGray);
}

//+------------------------------------------------------------------+
//| SuperTrend: dir[] and line[] for last n closed bars, series order |
//| index 0 = bar shift 1 (last closed)                               |
//+------------------------------------------------------------------+
bool CalcSuperTrend(int n, int &dir[], double &line[])
{
   int warm = 100;
   int total = n + warm;
   MqlRates r[];
   double atr[];
   ArraySetAsSeries(r, false);
   ArraySetAsSeries(atr, false);
   if(CopyRates(_Symbol, _Period, 1, total, r) != total) return false;
   if(CopyBuffer(hATR, 0, 1, total, atr) != total) return false;
   double up[], dn[]; int d[];
   ArrayResize(up, total); ArrayResize(dn, total); ArrayResize(d, total);
   for(int i=0; i<total; i++)
   {
      double hl2 = (r[i].high + r[i].low) / 2.0;
      double bu = hl2 - InpSTMult * atr[i];
      double bd = hl2 + InpSTMult * atr[i];
      if(i==0) { up[i]=bu; dn[i]=bd; d[i]=1; continue; }
      up[i] = (r[i-1].close > up[i-1]) ? MathMax(bu, up[i-1]) : bu;
      dn[i] = (r[i-1].close < dn[i-1]) ? MathMin(bd, dn[i-1]) : bd;
      if(d[i-1] == -1 && r[i].close > dn[i-1]) d[i] = 1;
      else if(d[i-1] == 1 && r[i].close < up[i-1]) d[i] = -1;
      else d[i] = d[i-1];
   }
   ArrayResize(dir, n); ArrayResize(line, n);
   for(int k=0; k<n; k++)
   {
      int i = total - 1 - k;
      dir[k]  = d[i];
      line[k] = (d[i]==1) ? up[i] : dn[i];
   }
   return true;
}

double Buf(int h, int buf, int shift)
{
   double v[];
   if(CopyBuffer(h, buf, shift, 1, v) != 1) return EMPTY_VALUE;
   return v[0];
}

//+------------------------------------------------------------------+
bool HasPosition(long &type, double &open, double &sl, double &tp, ulong &ticket)
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      type = PositionGetInteger(POSITION_TYPE);
      open = PositionGetDouble(POSITION_PRICE_OPEN);
      sl   = PositionGetDouble(POSITION_SL);
      tp   = PositionGetDouble(POSITION_TP);
      ticket = t;
      return true;
   }
   return false;
}

double CalcLot(double entry, double sl, ENUM_ORDER_TYPE ot)
{
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double lot;
   if(InpFixedLot > 0) lot = InpFixedLot * gLotMult;
   else
   {
      double riskMoney = AccountInfoDouble(ACCOUNT_BALANCE) * InpRiskPct / 100.0;
      double pl = 0;
      if(!OrderCalcProfit(ot, _Symbol, 1.0, entry, sl, pl) || pl == 0) return 0;
      lot = riskMoney * gLotMult / MathAbs(pl);
   }
   lot = MathFloor(lot / step) * step;
   lot = MathMin(lot, InpMaxLot);
   lot = MathMin(lot, maxLot);
   if(lot < minLot) return 0;   // risk juda kichik - savdo qilinmaydi
   return NormalizeDouble(lot, 2);
}

bool InSkip(int h)
{
   if(InpSkipStart < 0 || InpSkipEnd < 0 || InpSkipStart == InpSkipEnd) return false;
   if(InpSkipStart < InpSkipEnd) return (h >= InpSkipStart && h < InpSkipEnd);
   return (h >= InpSkipStart || h < InpSkipEnd);
}
bool SessionOK()
{
   MqlDateTime t; TimeToStruct(TimeCurrent(), t);
   if(InSkip(t.hour)) return false;
   if(!InpUseSession) return true;
   if(t.day_of_week==0 || t.day_of_week==6) return false;
   if(t.hour < InpStartHour || t.hour >= InpEndHour) return false;
   if(InpNoFriLate && t.day_of_week==5 && t.hour >= InpEndHour-3) return false;
   return true;
}

bool DailyLossOK()
{
   MqlDateTime t; TimeToStruct(TimeCurrent(), t);
   if(t.day_of_year != gDay)
   {
      gDay = t.day_of_year;
      gDayStartBal = AccountInfoDouble(ACCOUNT_BALANCE);
   }
   if(InpMaxDailyLossPct <= 0 || gDayStartBal <= 0) return true;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   return (gDayStartBal - eq) / gDayStartBal * 100.0 < InpMaxDailyLossPct;
}

void Notify(string s)
{
   Print(s);
   if(!InpNotify || MQLInfoInteger(MQL_TESTER)) return;
   Alert(s);
   SendNotification(s);
}

//+------------------------------------------------------------------+
void ManageBE()
{
   if(!InpMoveBE) return;
   long type; double open, sl, tp; ulong tk;
   if(!HasPosition(type, open, sl, tp, tk)) return;
   double risk = MathAbs(open - sl);
   if(risk <= 0) return;
   if(type==POSITION_TYPE_BUY)
   {
      if(sl >= open) return;
      double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      if(bid - open >= risk) trade.PositionModify(tk, open, tp);
   }
   else
   {
      if(sl <= open && sl > 0) return;
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      if(open - ask >= risk) trade.PositionModify(tk, open, tp);
   }
}

//+------------------------------------------------------------------+
void OnTick()
{
   ManageBE();

   datetime bt = iTime(_Symbol, _Period, 0);
   if(bt == gLastBar) return;
   gLastBar = bt;

   int n = InpSignalWindow + 2;
   int dir[]; double line[];
   if(!CalcSuperTrend(n, dir, line))
   {
      gLastBar = 0;   // tarix yetarli emas - keyingi tikda qayta urinish
      if(DrawOK()) { DrawDash(); ChartRedraw(); }
      return;
   }

   double atr  = Buf(hATR, 0, 1);
   double rsi  = Buf(hRSI, 0, 1);
   double macd = Buf(hMACD, 0, 1);
   double sig  = Buf(hMACD, 1, 1);
   double adx  = Buf(hADX, 0, 1);
   double pdi  = Buf(hADX, 1, 1);
   double mdi  = Buf(hADX, 2, 1);
   int    hs   = iBarShift(_Symbol, InpHTF, iTime(_Symbol, _Period, 1));
   double hema = Buf(hHTF, 0, hs < 0 ? 1 : hs);
   double hcls = iClose(_Symbol, InpHTF, hs < 0 ? 1 : hs);
   double c1   = iClose(_Symbol, _Period, 1);
   if(atr==EMPTY_VALUE || rsi==EMPTY_VALUE || macd==EMPTY_VALUE || adx==EMPTY_VALUE || hema==EMPTY_VALUE) return;

   int d = dir[0];
   // bars since flip
   int since = -1;
   for(int k=0; k<n-1; k++) if(dir[k] != dir[k+1]) { since = k; break; }

   // confirmations for direction d
   int c = 0;
   bool cHTF  = (d==1) ? (hcls > hema) : (hcls < hema);
   bool cRSI  = (d==1) ? (rsi > 50 && rsi < InpRSIMaxBuy) : (rsi < 50 && rsi > InpRSIMinSell);
   bool cMACD = (d==1) ? (macd - sig > 0) : (macd - sig < 0);
   bool cADX  = (adx >= InpADXMin) && ((d==1) ? (pdi > mdi) : (mdi > pdi));
   c = (int)cHTF + (int)cRSI + (int)cMACD + (int)cADX;

   gInfo = StringFormat("Gold Confluence EA\nSuperTrend: %s (%s)\nHTF EMA%d: %s | RSI %.1f: %s | MACD: %s | ADX %.1f: %s\nTasdiq: %d / 4 (kerak %d)",
             d==1?"BUY":"SELL", since<0?"eski":IntegerToString(since)+" sham oldin",
             InpHTFEMA, cHTF?"ha":"yo'q", rsi, cRSI?"ha":"yo'q", cMACD?"ha":"yo'q", adx, cADX?"ha":"yo'q", c, InpMinConfirm);
   gD = d; gSince = since; gC = c; gCH = cHTF; gCR = cRSI; gCM = cMACD; gCA = cADX; gRSI = rsi; gADX = adx;
   if(DrawOK())
   {
      DrawHistory();
      DrawDash();
      DrawPosLines();
      ChartRedraw();
   }
   else if(!MQLInfoInteger(MQL_TESTER)) Comment(gInfo);

   // position management on new bar
   long type; double open, sl, tp; ulong tk;
   bool has = HasPosition(type, open, sl, tp, tk);
   if(has && InpCloseOnFlip)
   {
      if((type==POSITION_TYPE_BUY && d==-1) || (type==POSITION_TYPE_SELL && d==1))
      {
         trade.PositionClose(tk);
         Notify(_Symbol+": SuperTrend teskari - pozitsiya yopildi");
         has = false;
      }
   }
   if(has) return;

   // entry conditions
   if(since < 0 || since >= InpSignalWindow) return;  // fresh flip only
   if(c < InpMinConfirm) return;
   if(d==1 && !InpAllowBuy) return;
   if(d==-1 && !InpAllowSell) return;
   if(!SessionOK()) return;
   if(!DailyLossOK()) return;
   if(InpMaxSpreadPts > 0 && SymbolInfoInteger(_Symbol, SYMBOL_SPREAD) > InpMaxSpreadPts) return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double entry = (d==1) ? ask : bid;
   double stl = line[0];
   double dist = MathAbs(entry - stl) + 0.1 * atr;
   dist = MathMax(dist, InpSLMinATR * atr);
   dist = MathMin(dist, InpSLMaxATR * atr);
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double slp = NormalizeDouble((d==1) ? entry - dist : entry + dist, digits);
   double tpp = NormalizeDouble((d==1) ? entry + InpRR * dist : entry - InpRR * dist, digits);
   ENUM_ORDER_TYPE ot = (d==1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   gLotMult = (c >= 4) ? InpLotMult4 : InpLotMult3;
   double lot = CalcLot(entry, slp, ot);
   if(lot <= 0) { Print("Lot juda kichik, savdo o'tkazib yuborildi"); return; }

   bool ok = (d==1) ? trade.Buy(lot, _Symbol, 0, slp, tpp, "GOLD "+IntegerToString(c))
                    : trade.Sell(lot, _Symbol, 0, slp, tpp, "GOLD "+IntegerToString(c));
   if(ok) Notify(StringFormat("%s %s %.2f lot | SL %.2f | TP %.2f | tasdiq %d/4",
                 _Symbol, d==1?"BUY":"SELL", lot, slp, tpp, c));
   else Print("Order xatosi: ", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
}
//+------------------------------------------------------------------+
