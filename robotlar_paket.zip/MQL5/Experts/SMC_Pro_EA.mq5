//+------------------------------------------------------------------+
//|                                                  SMC_Pro_EA.mq5  |
//|  Sovetnik: SMC Structure Pro indikatori signallari bo'yicha       |
//|  avtomatik savdo. TP = TP2 (sozlanadi), SL = indikator SL,        |
//|  lot = depozit foizi bo'yicha, TP1 dan keyin breakeven.            |
//|  DIQQAT: avval Strategy Tester va DEMO hisobda sinang.            |
//+------------------------------------------------------------------+
#property copyright "SMC Structure Pro EA"
#property version   "1.00"
#property description "SMC Structure Pro signallari bo'yicha avtomatik savdo (TP2, % risk, BE)."
#property tester_indicator "SMC_Structure_Pro_macOS.ex5"
#property tester_indicator "KN_LM_Combo.ex5"
#resource "\\Indicators\\SMC_Structure_Pro_macOS.ex5"
#resource "\\Indicators\\KN_LM_Combo.ex5"

#include <Trade\Trade.mqh>

input group "=== Indikator ==="
input string InpIndicatorName = "SMC_Structure_Pro_macOS"; // Indikator fayli nomi

input group "=== Savdo ==="
input int    InpTPLevel       = 2;      // Take Profit darajasi: 1 = TP1, 2 = TP2, 3 = TP3
input bool   InpBigOnly       = false;  // Faqat BIG BUY / BIG SELL signallarida savdo
input bool   InpAllowBuy      = true;   // BUY savdolariga ruxsat
input bool   InpAllowSell     = true;   // SELL savdolariga ruxsat
input bool   InpCloseOnOpp    = true;   // Teskari signalda pozitsiyani yopish
input bool   InpMoveBE        = true;   // TP1 urilganda SL -> Entry (breakeven)

input group "=== Risk ==="
input double InpRiskPct       = 1.0;    // Har savdoda risk, depozitning % i
input double InpFixedLot      = 0.0;    // Qat'iy lot (0 = risk % bo'yicha)
input double InpMaxLot        = 1.0;    // Maksimal lot
input double InpLotMultBig     = 1.0;    // Lot koeffitsienti: BIG signal
input double InpLotMultNorm    = 1.0;    // Lot koeffitsienti: oddiy signal
double gLotMult = 1.0;
input int    InpMaxSpreadPts  = 0;      // Maksimal spred, punkt (0 = tekshirmaslik)
input double InpMaxDailyLossPct = 3.0;  // Kunlik maksimal zarar, % (0 = o'chiq)

input group "=== Texnik ==="
input long   InpMagic         = 20261112; // Magic raqam
input int    InpSlippagePts   = 20;     // Sirpanish, punkt
input int    InpSkipStart     = -1;     // Kirmaslik oynasi boshi, server soati (-1 = o'chiq)
input int    InpSkipEnd       = -1;     // Kirmaslik oynasi oxiri, server soati
input bool   InpNotify        = true;   // Alert + Push

CTrade   trade;
int      hInd = INVALID_HANDLE;
datetime g_lastBar = 0;
double   g_dayStartBalance = 0;
int      g_day = -1;

void Say(const string msg)
  {
   Print(msg);
   if(!InpNotify || MQLInfoInteger(MQL_TESTER))
      return;
   Alert(msg);
   SendNotification(msg);
  }

double NormPrice(const double p)
  {
   double ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(ts <= 0)
      return NormalizeDouble(p, _Digits);
   return NormalizeDouble(MathRound(p / ts) * ts, _Digits);
  }

double CalcLot(const double entry, const double sl)
  {
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step    = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double lot;
   if(InpFixedLot > 0)
      lot = InpFixedLot * gLotMult;
   else
     {
      double tickVal  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(tickVal <= 0)
         tickVal = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
      double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
      double dist     = MathAbs(entry - sl);
      if(tickVal <= 0 || tickSize <= 0 || dist <= 0)
         return 0;
      double riskMoney  = AccountInfoDouble(ACCOUNT_BALANCE) * InpRiskPct / 100.0;
      double lossPerLot = dist / tickSize * tickVal;
      lot = riskMoney * gLotMult / lossPerLot;
     }
   lot = MathMin(lot, InpMaxLot);
   lot = MathMin(lot, maxLot);
   if(step > 0)
      lot = MathFloor(lot / step) * step;
   if(lot < minLot)
     {
      Print("Lot juda kichik (", DoubleToString(lot, 3), " < ", DoubleToString(minLot, 2), "), savdo ochilmadi.");
      return 0;
     }
   return NormalizeDouble(lot, 2);
  }

int MyPosition(ulong &ticket)
  {
   ticket = 0;
   for(int k = PositionsTotal() - 1; k >= 0; k--)
     {
      ulong t = PositionGetTicket(k);
      if(t == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol || PositionGetInteger(POSITION_MAGIC) != InpMagic)
         continue;
      ticket = t;
      return (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
     }
   return 0;
  }

bool DailyLossHit()
  {
   if(InpMaxDailyLossPct <= 0)
      return false;
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   if(dt.day_of_year != g_day)
     {
      g_day = dt.day_of_year;
      g_dayStartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
     }
   if(g_dayStartBalance <= 0)
      return false;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   return (g_dayStartBalance - eq) >= g_dayStartBalance * InpMaxDailyLossPct / 100.0;
  }

int OnInit()
  {
   if(InpTPLevel < 1 || InpTPLevel > 3 || InpRiskPct <= 0)
     {
      Print("Parametrlar noto'g'ri");
      return INIT_PARAMETERS_INCORRECT;
     }
   // indicators are embedded as resources (works on VPS without separate files)
   string indPath = InpIndicatorName;
   if(InpIndicatorName == "SMC_Structure_Pro_macOS") indPath = "::Indicators\\SMC_Structure_Pro_macOS.ex5";
   else if(InpIndicatorName == "KN_LM_Combo")         indPath = "::Indicators\\KN_LM_Combo.ex5";
   hInd = iCustom(_Symbol, _Period, indPath, true);
   if(hInd == INVALID_HANDLE)
     {
      Print("Indikator topilmadi: ", InpIndicatorName);
      return INIT_FAILED;
     }
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpSlippagePts);
   trade.SetTypeFillingBySymbol(_Symbol);
   g_lastBar = iTime(_Symbol, _Period, 0);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(hInd != INVALID_HANDLE)
      IndicatorRelease(hInd);
  }

void ManageBreakeven()
  {
   if(!InpMoveBE)
      return;
   ulong ticket;
   int dir = MyPosition(ticket);
   if(dir == 0 || !PositionSelectByTicket(ticket))
      return;
   string cmt = PositionGetString(POSITION_COMMENT);
   int sp = StringFind(cmt, "SMC ");
   if(sp < 0)
      return;
   double tp1 = StringToDouble(StringSubstr(cmt, sp + 4));
   if(tp1 <= 0)
      return;
   double open = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl   = PositionGetDouble(POSITION_SL);
   double tp   = PositionGetDouble(POSITION_TP);
   double bid  = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask  = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   if(dir > 0 && bid >= tp1 && (sl < open || sl == 0))
     {
      if(trade.PositionModify(ticket, NormPrice(open), tp))
         Say(StringFormat("SMC EA %s: TP1 urildi, SL -> breakeven %s", _Symbol, DoubleToString(open, _Digits)));
     }
   else
      if(dir < 0 && ask <= tp1 && (sl > open || sl == 0))
        {
         if(trade.PositionModify(ticket, NormPrice(open), tp))
            Say(StringFormat("SMC EA %s: TP1 urildi, SL -> breakeven %s", _Symbol, DoubleToString(open, _Digits)));
        }
  }

bool InSkip(int h)
{
   if(InpSkipStart < 0 || InpSkipEnd < 0 || InpSkipStart == InpSkipEnd) return false;
   if(InpSkipStart < InpSkipEnd) return (h >= InpSkipStart && h < InpSkipEnd);
   return (h >= InpSkipStart || h < InpSkipEnd);
}

void OnTick()
  {
   ManageBreakeven();
   datetime bar0 = iTime(_Symbol, _Period, 0);
   if(bar0 == g_lastBar)
      return;
   if(BarsCalculated(hInd) <= 0)
      return;
   double sig[1], slb[1], tp1b[1], tp2b[1], tp3b[1];
   if(CopyBuffer(hInd, 7, 1, 1, sig) != 1 || CopyBuffer(hInd, 8, 1, 1, slb) != 1 ||
      CopyBuffer(hInd, 9, 1, 1, tp1b) != 1 || CopyBuffer(hInd, 10, 1, 1, tp2b) != 1 ||
      CopyBuffer(hInd, 11, 1, 1, tp3b) != 1)
      return;
   g_lastBar = bar0;

   int s = (int)MathRound(sig[0]);
   if(s == 0)
      return;
   int  dir = (s > 0) ? 1 : -1;
   bool big = (MathAbs(s) >= 2);
   if(InpBigOnly && !big)
      return;
   if((dir > 0 && !InpAllowBuy) || (dir < 0 && !InpAllowSell))
      return;

   ulong ticket;
   int cur = MyPosition(ticket);
   if(cur == dir)
      return;
   if(cur != 0)
     {
      if(!InpCloseOnOpp)
         return;
      if(trade.PositionClose(ticket))
         Say(StringFormat("SMC EA %s: teskari signal, pozitsiya yopildi", _Symbol));
      else
         return;
     }
   { MqlDateTime st; TimeToStruct(TimeCurrent(), st); if(InSkip(st.hour)) return; }
   if(DailyLossHit())
     {
      Print("Kunlik zarar chegarasiga yetildi, bugun yangi savdo ochilmaydi.");
      return;
     }
   if(InpMaxSpreadPts > 0 && SymbolInfoInteger(_Symbol, SYMBOL_SPREAD) > InpMaxSpreadPts)
     {
      Print("Spred juda katta, savdo ochilmadi.");
      return;
     }
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double entry = (dir > 0) ? ask : bid;
   double sl  = NormPrice(slb[0]);
   double tp  = NormPrice(InpTPLevel == 1 ? tp1b[0] : (InpTPLevel == 3 ? tp3b[0] : tp2b[0]));
   double tp1 = NormPrice(tp1b[0]);
   if(dir > 0 && (sl >= entry || tp <= entry))
      return;
   if(dir < 0 && (sl <= entry || tp >= entry))
      return;
   double minDist = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   if(MathAbs(entry - sl) < minDist || MathAbs(tp - entry) < minDist)
     {
      Print("SL/TP broker minimal masofasidan yaqin, savdo ochilmadi.");
      return;
     }
   gLotMult = big ? InpLotMultBig : InpLotMultNorm;
   double lot = CalcLot(entry, sl);
   if(lot <= 0)
      return;
   string cmt = "SMC " + DoubleToString(tp1, _Digits);
   bool ok = (dir > 0) ? trade.Buy(lot, _Symbol, 0, sl, tp, cmt) : trade.Sell(lot, _Symbol, 0, sl, tp, cmt);
   if(ok && (trade.ResultRetcode() == TRADE_RETCODE_DONE || trade.ResultRetcode() == TRADE_RETCODE_PLACED))
      Say(StringFormat("SMC EA %s: %s%s %.2f lot | SL %s | TP%d %s",
                       _Symbol, big ? "BIG " : "", dir > 0 ? "BUY" : "SELL", lot,
                       DoubleToString(sl, _Digits), InpTPLevel, DoubleToString(tp, _Digits)));
   else
      Print("Savdo ochilmadi: ", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
  }
