//+------------------------------------------------------------------+
//|                                                 KN_LM_Combo.mq5  |
//|  MT5 port of two TradingView scripts used by the user:            |
//|   1) "KN - Smart TP SL Signals"  (EMA 5/13 cross, SL = 1.5*ATR,    |
//|      TP1/TP2/TP3 = 1R/2R/3R)                                       |
//|   2) "Structured zigzag support&resistance [LM]" (zigzag depth 34, |
//|      deviation 6, HH/HL/LH/LL, horizontal S/R lines or boxes,     |
//|      diagonal S/R lines)                                           |
//|  + dashboard (BIG BUY / BIG SELL = signal agrees with zigzag      |
//|    structure), sound/push alerts, honest statistics in R.         |
//|  Calculated on CLOSED bars only (no repaint).                     |
//|  Not financial advice.                                            |
//+------------------------------------------------------------------+
#property copyright   "KN + LM port"
#property version     "1.00"
#property description "KN Smart TP SL Signals + Structured zigzag S/R [LM] (MT5 port)"
#property indicator_chart_window
#property indicator_buffers 12
#property indicator_plots   2

#property indicator_label1  "EMA Fast"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrGreen
#property indicator_width1  1

#property indicator_label2  "EMA Slow"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrRed
#property indicator_width2  1

#define PFX "KNLM_"

input bool   InpEAMode         = false;  // EA rejimi (faqat sovetnik uchun, o'zgartirmang)

input group "=== KN Smart TP SL ==="
input int    InpFastEMA        = 5;      // Fast EMA
input int    InpSlowEMA        = 13;     // Slow EMA
input int    InpATRLen         = 14;     // ATR davri (RMA, TradingView kabi)
input double InpSLATRMult      = 1.5;    // SL = ATR x
input double InpRR1            = 1.0;    // TP1 RR
input double InpRR2            = 2.0;    // TP2 RR
input double InpRR3            = 3.0;    // TP3 RR
input bool   InpShowRisk       = true;   // TP/SL chiziqlarini ko'rsatish
input int    InpLabelOffset    = 15;     // Chiziq uzunligi (bar)
input bool   InpOnlyLatest     = true;   // Faqat oxirgi BUY/SELL yozuvi
input bool   InpStopAfterSL    = true;   // SL dan keyin TP ni belgilamaslik (asl kodda xato bor)
input color  InpBullColor      = clrLime;
input color  InpBearColor      = clrRed;
input color  InpTPColor        = clrAqua;
input color  InpSLColor        = clrOrange;
input color  InpProfitFill     = C'205,240,210';
input color  InpLossFill       = C'250,210,210';

input group "=== Structured zigzag S/R [LM] ==="
input bool   InpUseBoxes       = false;  // Gorizontal tur: false = chiziq, true = quti
input int    InpDepth          = 34;     // Depth
input double InpDeviation      = 6.0;    // Deviation (tick)
input color  InpSRColor        = clrBlue;// S/R chiziq rangi
input bool   InpExtendLines    = true;   // Chiziqlarni uzaytirish
input int    InpLineCount      = 6;      // Gorizontal chiziqlar soni
input color  InpBoxHighColor   = C'190,235,200'; // Quti (high) rangi
input color  InpBoxLowColor    = C'250,200,205'; // Quti (low) rangi
input color  InpDiagColor      = clrGray;// Zigzag rangi
input int    InpZigzagCount    = 200;    // Zigzag soni
input color  InpDiagHighColor  = clrGreen; // High rangi (HH/LH)
input color  InpDiagLowColor   = clrRed;   // Low rangi (HL/LL)
input int    InpDiagSRCount    = 2;      // Diagonal S/R chiziqlar soni
input bool   InpShowDiagSR     = true;   // Diagonal S/R chiziqlar

input group "=== Dashbord ==="
input bool   InpShowDash       = true;   // Dashbord
input int    InpDashX          = 12;     // X
input int    InpDashY          = 40;     // Y
input double InpDashScale      = 0;      // Masshtab (0 = avto)
input string InpFont           = "Arial";
input int    InpFontSize       = 9;
input color  InpDashBg         = C'18,24,38';
input color  InpDashBorder     = C'60,75,110';
input color  InpDashText       = C'190,200,222';

input group "=== Ogohlantirish ==="
input bool   InpAlertPopup     = true;   // Alert oynasi
input bool   InpAlertSound     = true;   // Ovoz
input bool   InpAlertPush      = false;  // Push (MT5 mobil)
input bool   InpAlertEmail     = false;  // E-mail
input bool   InpAlertBigOnly   = false;  // Faqat BIG signallarda

input group "=== Tarix ==="
input int    InpHistoryBars    = 3000;   // Hisoblanadigan barlar

//==================================================================
double gFast[], gSlow[], gAtr[], gHighing[], gLowing[], gD1[], gD2[];
double gSig[], gSLb[], gTP1b[], gTP2b[], gTP3b[];
int    hFast = INVALID_HANDLE, hSlow = INVALID_HANDLE;

// zigzag state
int      g_lw, g_hg, g_lastNotH, g_lastNotL;
bool     g_prevDown, g_downInit;
double   g_val[];
int      g_type[];          // +1 HIGH, -1 LOW
datetime g_time[];
string   g_lastHighTag, g_lastLowTag;
double   g_lastHighVal, g_lastLowVal;

struct SHor { double y; double y2; datetime t0; int type; };
SHor     g_hor[];
datetime g_zz[];            // zigzag line end times (for deletion)
datetime g_ds[];            // diagonal S/R line times

// KN trade state
int      g_dir;
double   g_en, g_sl, g_t1, g_t2, g_t3;
bool     g_h1, g_h2, g_h3, g_hs;
datetime g_t0, g_tFin;
int      g_startIdx;
bool     g_big;
string   g_lastBuyLbl, g_lastSellLbl;

// honest stats (exit at TPk / SL / opposite signal), in R
bool     g_kOpen[3];
double   g_kR[3];
int      g_kWin[3], g_kLoss[3];
int      g_signals, g_bigSignals;

bool     g_ready, g_live;
int      g_lastIdx;
datetime g_lastTime;
double   g_sc = 1.0;

//==================================================================
string TFStr() { return StringSubstr(EnumToString((ENUM_TIMEFRAMES)_Period), 7); }
string Px(const double v) { return DoubleToString(v, _Digits); }
int    S(const int v) { return (int)MathRound(v * g_sc); }

void MkText(const string name, const datetime t, const double p, const string txt, const color c,
            const int fs, const ENUM_ANCHOR_POINT anc)
  {
   if(InpEAMode)
      return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TEXT, 0, t, p);
   else
      ObjectMove(0, name, 0, t, p);
   ObjectSetString(0, name, OBJPROP_TEXT, txt);
   ObjectSetString(0, name, OBJPROP_FONT, InpFont);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anc);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
  }

void MkLine(const string name, const datetime t1, const double p1, const datetime t2, const double p2,
            const color c, const ENUM_LINE_STYLE st, const int w, const bool ray)
  {
   if(InpEAMode)
      return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, p1, t2, p2);
   else
     {
      ObjectMove(0, name, 0, t1, p1);
      ObjectMove(0, name, 1, t2, p2);
     }
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_STYLE, st);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, w);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, ray);
   ObjectSetInteger(0, name, OBJPROP_RAY_LEFT, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
  }

void MkRect(const string name, const datetime t1, const double p1, const datetime t2, const double p2, const color c)
  {
   if(InpEAMode)
      return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_RECTANGLE, 0, t1, p1, t2, p2);
   else
     {
      ObjectMove(0, name, 0, t1, p1);
      ObjectMove(0, name, 1, t2, p2);
     }
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_FILL, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
  }

void DashRect(const string name, const int x, const int y, const int w, const int h, const color bg, const color border)
  {
   if(InpEAMode)
      return;
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
     }
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, name, OBJPROP_COLOR, border);
  }

void DashLabel(const string name, const int x, const int y, const string text, const color c,
               const int fs, const ENUM_ANCHOR_POINT anc)
  {
   if(InpEAMode)
      return;
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
     }
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anc);
   ObjectSetString(0, name, OBJPROP_TEXT, (text == "") ? " " : text);
   ObjectSetString(0, name, OBJPROP_FONT, InpFont);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
  }

void Notify(const string msg, const bool big)
  {
   if(InpEAMode || (InpAlertBigOnly && !big))
      return;
   if(InpAlertPopup)
      Alert(msg);
   if(InpAlertSound)
      PlaySound(big ? "alert2.wav" : "alert.wav");
   if(InpAlertPush)
      SendNotification(msg);
   if(InpAlertEmail)
      SendMail("KN+LM " + _Symbol + " " + TFStr(), msg);
  }

bool CopyInd(const int handle, const int rates_total, const int count, double &dst[])
  {
   double tmp[];
   ArraySetAsSeries(tmp, true);
   int got = CopyBuffer(handle, 0, 0, count, tmp);
   if(got <= 0)
      return false;
   for(int k = 0; k < got; k++)
      dst[rates_total - 1 - k] = tmp[k];
   return true;
  }

//==================================================================
void ResetState()
  {
   g_lw = 1; g_hg = 1; g_lastNotH = -1; g_lastNotL = -1;
   g_prevDown = false; g_downInit = false;
   ArrayResize(g_val, 0); ArrayResize(g_type, 0); ArrayResize(g_time, 0);
   ArrayResize(g_hor, 0); ArrayResize(g_zz, 0); ArrayResize(g_ds, 0);
   g_lastHighTag = "-"; g_lastLowTag = "-"; g_lastHighVal = 0; g_lastLowVal = 0;
   g_dir = 0; g_en = 0; g_sl = 0; g_t1 = 0; g_t2 = 0; g_t3 = 0;
   g_h1 = false; g_h2 = false; g_h3 = false; g_hs = false; g_t0 = 0; g_tFin = 0; g_startIdx = -1; g_big = false;
   g_lastBuyLbl = ""; g_lastSellLbl = "";
   for(int k = 0; k < 3; k++)
     {
      g_kOpen[k] = false; g_kR[k] = 0; g_kWin[k] = 0; g_kLoss[k] = 0;
     }
   g_signals = 0; g_bigSignals = 0;
   g_ready = false; g_live = false; g_lastIdx = -1; g_lastTime = 0;
  }

//==================================================================
// Structured zigzag [LM]
//==================================================================
string HorName(const int k) { return PFX + "HL_" + (string)(long)g_hor[k].t0 + "_" + (string)g_hor[k].type; }

void RemoveHor(const int k)
  {
   ObjectDelete(0, HorName(k));
   ObjectDelete(0, HorName(k) + "T");
   int n = ArraySize(g_hor);
   for(int j = k; j < n - 1; j++)
      g_hor[j] = g_hor[j + 1];
   ArrayResize(g_hor, n - 1);
  }

void PushTime(datetime &arr[], const datetime t, const int maxN, const string prefix, const string prefix2)
  {
   int n = ArraySize(arr);
   if(n >= MathMax(1, maxN))
     {
      ObjectDelete(0, prefix + (string)(long)arr[0]);
      if(prefix2 != "")
         ObjectDelete(0, prefix2 + (string)(long)arr[0]);
      for(int j = 0; j < n - 1; j++)
         arr[j] = arr[j + 1];
      n--;
      ArrayResize(arr, n);
     }
   ArrayResize(arr, n + 1);
   arr[n] = t;
  }

void DrawHor(const int k, const datetime tEnd)
  {
   string nm = HorName(k);
   if(InpUseBoxes)
     {
      double top = MathMax(g_hor[k].y, g_hor[k].y2), bot = MathMin(g_hor[k].y, g_hor[k].y2);
      if(top - bot < _Point)
         top = bot + _Point;
      MkRect(nm, g_hor[k].t0, top, tEnd, bot, g_hor[k].type > 0 ? InpBoxHighColor : InpBoxLowColor);
     }
   else
      MkLine(nm, g_hor[k].t0, g_hor[k].y, tEnd, g_hor[k].y, InpSRColor, STYLE_DOT, 2, false);
   MkText(nm + "T", tEnd, g_hor[k].y, "  " + Px(g_hor[k].y), InpUseBoxes ? (g_hor[k].type > 0 ? InpDiagHighColor : InpDiagLowColor) : InpSRColor,
          InpFontSize - 1, ANCHOR_LEFT);
  }

void AddPivot(const int i, const int p, const bool down, const datetime &time[], const double &open[],
              const double &high[], const double &low[], const double &close[])
  {
   double   y    = down ? high[p] : low[p];
   datetime tp   = time[p];
   int      type = down ? 1 : -1;
   int      n    = ArraySize(g_val);

   // zigzag diagonal (from last pivot)
   if(n >= 1)
     {
      PushTime(g_zz, tp, InpZigzagCount, PFX + "ZZ_", PFX + "ZL_");
      MkLine(PFX + "ZZ_" + (string)(long)tp, g_time[n - 1], g_val[n - 1], tp, y, InpDiagColor, STYLE_DASH, 1, false);
     }
   // diagonal S/R from previous same-type pivot
   if(InpShowDiagSR && n >= 2)
     {
      color dc = (g_type[n - 2] == 1) ? InpDiagHighColor : InpDiagLowColor;
      PushTime(g_ds, tp, InpDiagSRCount, PFX + "DS_", "");
      MkLine(PFX + "DS_" + (string)(long)tp, g_time[n - 2], g_val[n - 2], tp, y, dc, STYLE_DASH, 1, true);
     }
   // store pivot
   if(n >= InpZigzagCount && n > 0)
     {
      for(int j = 0; j < n - 1; j++)
        {
         g_val[j] = g_val[j + 1]; g_type[j] = g_type[j + 1]; g_time[j] = g_time[j + 1];
        }
      n--;
     }
   ArrayResize(g_val, n + 1); ArrayResize(g_type, n + 1); ArrayResize(g_time, n + 1);
   g_val[n] = y; g_type[n] = type; g_time[n] = tp;
   n++;

   // horizontal S/R line or box
   if(ArraySize(g_hor) >= MathMax(1, InpLineCount))
      RemoveHor(0);
   int h = ArraySize(g_hor);
   ArrayResize(g_hor, h + 1);
   g_hor[h].t0 = tp; g_hor[h].type = type; g_hor[h].y = y;
   bool isUp = open[p] <= close[p];
   if(InpUseBoxes)
      g_hor[h].y2 = down ? (isUp ? close[p] : open[p]) : (isUp ? open[p] : close[p]);
   else
      g_hor[h].y2 = y;
   DrawHor(h, time[i]);

   // HH / LH / HL / LL label
   string tag = "";
   if(n - 3 >= 0)
     {
      double pv = g_val[n - 3];
      if(g_type[n - 3] == 1)
         tag = (pv <= y) ? "HH" : "LH";
      else
         tag = (pv <= y) ? "HL" : "LL";
     }
   if(tag != "")
     {
      MkText(PFX + "ZL_" + (string)(long)tp, tp, y, tag, down ? InpDiagHighColor : InpDiagLowColor,
             InpFontSize, down ? ANCHOR_LOWER : ANCHOR_UPPER);
      if(down)
        { g_lastHighTag = tag; g_lastHighVal = y; }
      else
        { g_lastLowTag = tag; g_lastLowVal = y; }
     }
  }

void ZigzagBar(const int i, const datetime &time[], const double &open[], const double &high[],
               const double &low[], const double &close[])
  {
   g_lw++;
   g_hg++;
   int d = MathMax(1, InpDepth);
   int lowestOff = 0, highestOff = 0;
   double lo = low[i], hi = high[i];
   for(int k = 1; k < d && i - k >= 0; k++)
     {
      if(low[i - k] < lo)  { lo = low[i - k];  lowestOff = k; }
      if(high[i - k] > hi) { hi = high[i - k]; highestOff = k; }
     }
   double tick = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tick <= 0)
      tick = _Point;
   bool lowing  = (g_lw == lowestOff)  || (low[i] - low[i - lowestOff] > InpDeviation * tick);
   bool highing = (g_hg == highestOff) || (high[i - highestOff] - high[i] > InpDeviation * tick);
   gHighing[i] = highing ? 1 : 0;
   gLowing[i]  = lowing ? 1 : 0;
   if(!highing)
      g_lastNotH = i;
   if(!lowing)
      g_lastNotL = i;
   int lh = (g_lastNotH < 0) ? -1 : i - g_lastNotH;
   int ll = (g_lastNotL < 0) ? -1 : i - g_lastNotL;
   bool down = (lh >= 0 && ll >= 0) ? (lh > ll) : false;
   bool lower  = (i - g_lw >= 0) ? (low[i - g_lw] > low[i - lowestOff]) : false;
   bool higher = (i - g_hg >= 0) ? (high[i - g_hg] < high[i - highestOff]) : false;
   bool prevDown = g_prevDown;
   if(g_lw != lowestOff && (!prevDown || lower))
      g_lw = (lowestOff < g_hg) ? lowestOff : 0;
   if(g_hg != highestOff && (prevDown || higher))
      g_hg = (highestOff < g_lw) ? highestOff : 0;
   bool sw = g_downInit && (down != prevDown);
   g_prevDown = down;
   g_downInit = true;
   if(sw)
     {
      int nx = down ? g_hg : g_lw;
      int p = i - nx;
      if(p >= 0)
         AddPivot(i, p, down, time, open, high, low, close);
     }
  }

//==================================================================
// KN Smart TP SL
//==================================================================
string TRN(const string s) { return PFX + "TR_" + s; }

void DrawTrade(const datetime tStart, const datetime tEnd)
  {
   if(!InpShowRisk || g_dir == 0)
      return;
   int fs = InpFontSize - 1;
   MkRect(TRN("PB"), tStart, (g_dir > 0 ? g_t3 : g_en), tEnd, (g_dir > 0 ? g_en : g_t3), InpProfitFill);
   MkRect(TRN("LB"), tStart, (g_dir > 0 ? g_en : g_sl), tEnd, (g_dir > 0 ? g_sl : g_en), InpLossFill);
   MkLine(TRN("LE"), tStart, g_en, tEnd, g_en, clrGray, STYLE_SOLID, 2, false);
   MkLine(TRN("LS"), tStart, g_sl, tEnd, g_sl, g_hs ? clrRed : InpSLColor, STYLE_SOLID, 2, false);
   MkLine(TRN("L1"), tStart, g_t1, tEnd, g_t1, g_h1 ? clrGreen : InpTPColor, g_h1 ? STYLE_SOLID : STYLE_DASH, 1, false);
   MkLine(TRN("L2"), tStart, g_t2, tEnd, g_t2, g_h2 ? clrGreen : InpTPColor, g_h2 ? STYLE_SOLID : STYLE_DASH, 1, false);
   MkLine(TRN("L3"), tStart, g_t3, tEnd, g_t3, g_h3 ? clrGreen : InpTPColor, STYLE_SOLID, 2, false);
   datetime tl = tEnd + PeriodSeconds() * 2;
   MkText(TRN("XE"), tl, g_en, "ENTRY " + Px(g_en), clrGray, fs, ANCHOR_LEFT);
   MkText(TRN("XS"), tl, g_sl, g_hs ? "SL X" : "SL " + Px(g_sl), g_hs ? clrRed : InpSLColor, fs, ANCHOR_LEFT);
   MkText(TRN("X1"), tl, g_t1, g_h1 ? "TP1 OK" : "TP1 " + Px(g_t1), g_h1 ? clrGreen : InpTPColor, fs, ANCHOR_LEFT);
   MkText(TRN("X2"), tl, g_t2, g_h2 ? "TP2 OK" : "TP2 " + Px(g_t2), g_h2 ? clrGreen : InpTPColor, fs, ANCHOR_LEFT);
   MkText(TRN("X3"), tl, g_t3, g_h3 ? "TP3 OK" : "TP3 " + Px(g_t3), g_h3 ? clrGreen : InpTPColor, fs, ANCHOR_LEFT);
  }

int Structure()
  {
   bool bull = (g_lastHighTag == "HH" && g_lastLowTag == "HL");
   bool bear = (g_lastHighTag == "LH" && g_lastLowTag == "LL");
   return bull ? 1 : (bear ? -1 : 0);
  }

void StatsCloseAll(const double price)
  {
   double rr[3];
   rr[0] = InpRR1; rr[1] = InpRR2; rr[2] = InpRR3;
   double risk = MathAbs(g_en - g_sl);
   for(int k = 0; k < 3; k++)
     {
      if(!g_kOpen[k] || risk <= 0)
         continue;
      double r = (price - g_en) * g_dir / risk;
      g_kR[k] += r;
      if(r > 0) g_kWin[k]++; else g_kLoss[k]++;
      g_kOpen[k] = false;
     }
  }

void StatsBar(const int i, const double &high[], const double &low[])
  {
   double rr[3], tp[3];
   rr[0] = InpRR1; rr[1] = InpRR2; rr[2] = InpRR3;
   tp[0] = g_t1;   tp[1] = g_t2;   tp[2] = g_t3;
   for(int k = 0; k < 3; k++)
     {
      if(!g_kOpen[k])
         continue;
      bool slT = (g_dir > 0) ? (low[i] <= g_sl) : (high[i] >= g_sl);
      bool tpT = (g_dir > 0) ? (high[i] >= tp[k]) : (low[i] <= tp[k]);
      if(slT)            // conservative: SL first if both in one bar
        { g_kR[k] -= 1.0; g_kLoss[k]++; g_kOpen[k] = false; }
      else if(tpT)
        { g_kR[k] += rr[k]; g_kWin[k]++; g_kOpen[k] = false; }
     }
  }

void KNBar(const int i, const datetime &time[], const double &high[], const double &low[], const double &close[])
  {
   gSig[i] = 0; gSLb[i] = 0; gTP1b[i] = 0; gTP2b[i] = 0; gTP3b[i] = 0;
   // honest stats for open trade (bars after entry)
   if(g_dir != 0 && i > g_startIdx)
      StatsBar(i, high, low);

   bool buy = false, sell = false;
   if(i >= 1 && gFast[i] != EMPTY_VALUE && gSlow[i] != EMPTY_VALUE && gFast[i - 1] != EMPTY_VALUE && gSlow[i - 1] != EMPTY_VALUE)
     {
      buy  = gFast[i] > gSlow[i] && gFast[i - 1] <= gSlow[i - 1];
      sell = gFast[i] < gSlow[i] && gFast[i - 1] >= gSlow[i - 1];
     }
   if(buy || sell)
     {
      int dir = buy ? 1 : -1;
      StatsCloseAll(close[i]);           // opposite/new signal closes stat trades at close
      double atr = gAtr[i];
      if(atr <= 0 || atr == EMPTY_VALUE)
         atr = high[i] - low[i];
      double risk = atr * InpSLATRMult;
      g_dir = dir; g_en = close[i];
      g_sl = close[i] - dir * risk;
      g_t1 = close[i] + dir * risk * InpRR1;
      g_t2 = close[i] + dir * risk * InpRR2;
      g_t3 = close[i] + dir * risk * InpRR3;
      g_h1 = false; g_h2 = false; g_h3 = false; g_hs = false;
      g_t0 = time[i]; g_tFin = 0; g_startIdx = i;
      int st = Structure();
      g_big = (st == dir);
      g_signals++;
      if(g_big)
         g_bigSignals++;
      for(int k = 0; k < 3; k++)
         g_kOpen[k] = true;

      gSig[i] = dir * (g_big ? 2 : 1);
      gSLb[i] = g_sl; gTP1b[i] = g_t1; gTP2b[i] = g_t2; gTP3b[i] = g_t3;

      if(!InpEAMode)
        {
         string txt = (g_big ? "BIG " : "") + (buy ? "BUY" : "SELL");
         string nm = PFX + (buy ? "SB_" : "SS_") + (string)(long)time[i];
         if(InpOnlyLatest)
           {
            if(buy && g_lastBuyLbl != "")
               ObjectDelete(0, g_lastBuyLbl);
            if(sell && g_lastSellLbl != "")
               ObjectDelete(0, g_lastSellLbl);
           }
         MkText(nm, time[i], buy ? low[i] : high[i], txt, buy ? InpBullColor : InpBearColor,
                g_big ? InpFontSize + 2 : InpFontSize, buy ? ANCHOR_UPPER : ANCHOR_LOWER);
         if(buy) g_lastBuyLbl = nm; else g_lastSellLbl = nm;
         ObjectsDeleteAll(0, PFX + "TR_");
        }
      if(g_live)
        {
         string msg = StringFormat("KN+LM %s %s: %s%s @ %s | SL %s | TP1 %s | TP2 %s | TP3 %s | tuzilma %s",
                                   _Symbol, TFStr(), g_big ? "BIG " : "", buy ? "BUY" : "SELL", Px(g_en), Px(g_sl),
                                   Px(g_t1), Px(g_t2), Px(g_t3), g_big ? "mos" : "mos emas");
         Notify(msg, g_big);
        }
     }

   // TP/SL hit marks (as in the original: also checked on the signal bar)
   if(g_dir != 0)
     {
      bool stop = InpStopAfterSL && (g_hs || g_h3);
      if(!stop)
        {
         bool slT = (g_dir > 0) ? (low[i] <= g_sl) : (high[i] >= g_sl);
         if(InpStopAfterSL && slT && i > g_startIdx)
            g_hs = true;
         else
           {
            if(!g_h1 && ((g_dir > 0) ? high[i] >= g_t1 : low[i] <= g_t1)) g_h1 = true;
            if(!g_h2 && ((g_dir > 0) ? high[i] >= g_t2 : low[i] <= g_t2)) g_h2 = true;
            if(!g_h3 && ((g_dir > 0) ? high[i] >= g_t3 : low[i] <= g_t3)) g_h3 = true;
            if(!InpStopAfterSL && slT) g_hs = true;
           }
        }
     }
   if(g_dir != 0 && g_tFin == 0 && (g_hs || g_h3))
      g_tFin = (i >= 1) ? time[i - 1] : time[i];
  }

//==================================================================
void CalcScale()
  {
   if(InpDashScale > 0)
     { g_sc = InpDashScale; return; }
   double dpi = (double)TerminalInfoInteger(TERMINAL_SCREEN_DPI);
   g_sc = (dpi > 0) ? dpi / 96.0 : 1.0;
   uint tw = 0, th = 0;
   if(TextSetFont(InpFont, -InpFontSize * 10) && TextGetSize("Tuzilma trendi", tw, th) && th > 0)
     {
      double m = th / (InpFontSize * 1.45);
      if(m > g_sc)
         g_sc = m;
     }
   if(g_sc < 1.0) g_sc = 1.0;
   if(g_sc > 3.0) g_sc = 3.0;
  }

void Row(const int x, const int y0, const int W, const int r, const int rowH, const string key, const string val, const color vc)
  {
   int yy = y0 + r * rowH;
   DashLabel(PFX + "D_K" + (string)r, x + S(10), yy, key, InpDashText, InpFontSize, ANCHOR_LEFT_UPPER);
   DashLabel(PFX + "D_V" + (string)r, x + W - S(10), yy, val, vc, InpFontSize, ANCHOR_RIGHT_UPPER);
  }

string StatTxt(const int k)
  {
   int n = g_kWin[k] + g_kLoss[k];
   if(n == 0)
      return "-";
   return StringFormat("%+.1fR  %d/%d (%.0f%%)", g_kR[k], g_kWin[k], n, 100.0 * g_kWin[k] / n);
  }

void DrawDashboard(const int rates_total, const double &close[])
  {
   if(!InpShowDash || InpEAMode)
      return;
   CalcScale();
   int c = rates_total - 2;
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(bid <= 0)
      bid = close[rates_total - 1];
   int x = S(InpDashX), y = S(InpDashY), W = S(310);
   int rowH = S(InpFontSize + 8);
   int nRows = 19;
   int bannerY = y + S(32), bannerH = S(34);
   int y0 = bannerY + bannerH + S(8);
   int H = (y0 - y) + nRows * rowH + S(8);
   color cB = C'0,170,90', cS = C'220,40,60', cN = C'150,160,180', cH = C'255,200,80';

   DashRect(PFX + "D_BG", x, y, W, H, InpDashBg, InpDashBorder);
   DashRect(PFX + "D_HDR", x, y, W, S(26), C'28,38,62', InpDashBorder);
   DashLabel(PFX + "D_T1", x + S(10), y + S(5), "KN + LM", clrWhite, InpFontSize + 1, ANCHOR_LEFT_UPPER);
   DashLabel(PFX + "D_T2", x + W - S(10), y + S(6), _Symbol + " | " + TFStr(), cH, InpFontSize + 1, ANCHOR_RIGHT_UPPER);

   bool active = (g_dir != 0 && !g_hs && !g_h3);
   string ban = "SIGNAL KUTILMOQDA";
   color  bg  = C'45,55,80';
   if(g_dir != 0)
     {
      ban = (g_big ? "BIG " : "") + (g_dir > 0 ? "BUY" : "SELL");
      if(!active)
         ban += " (yopildi)";
      bg = g_dir > 0 ? (g_big ? C'0,140,75' : C'20,85,55') : (g_big ? C'190,25,45' : C'105,30,40');
      if(!active)
         bg = C'45,55,80';
     }
   DashRect(PFX + "D_BAN", x + S(6), bannerY, W - S(12), bannerH, bg, InpDashBorder);
   DashLabel(PFX + "D_BANT", x + W / 2, bannerY + bannerH / 2, ban, clrWhite, InpFontSize + 3, ANCHOR_CENTER);

   int st = Structure();
   string stTxt = st > 0 ? "^ BULLISH (HH+HL)" : (st < 0 ? "v BEARISH (LH+LL)" : "- ARALASH");
   color  stC   = st > 0 ? cB : (st < 0 ? cS : cN);
   bool   up    = gFast[c] > gSlow[c];
   int r = 0;
   Row(x, y0, W, r++, rowH, "Narx (Bid)", Px(bid), clrWhite);
   Row(x, y0, W, r++, rowH, "Zigzag tuzilma", stTxt, stC);
   Row(x, y0, W, r++, rowH, "Oxirgi high", g_lastHighTag + (g_lastHighVal > 0 ? "  " + Px(g_lastHighVal) : ""), g_lastHighTag == "HH" ? cB : cS);
   Row(x, y0, W, r++, rowH, "Oxirgi low", g_lastLowTag + (g_lastLowVal > 0 ? "  " + Px(g_lastLowVal) : ""), g_lastLowTag == "HL" ? cB : cS);
   Row(x, y0, W, r++, rowH, StringFormat("EMA %d / %d", InpFastEMA, InpSlowEMA), up ? "^ Fast > Slow" : "v Fast < Slow", up ? cB : cS);
   Row(x, y0, W, r++, rowH, StringFormat("ATR (%d)", InpATRLen), Px(gAtr[c]), clrWhite);
   Row(x, y0, W, r++, rowH, "---- SIGNAL ----", "", cH);
   if(g_dir != 0)
     {
      color dc = g_dir > 0 ? cB : cS;
      Row(x, y0, W, r++, rowH, "Signal", (g_dir > 0 ? "BUY  " : "SELL  ") + TimeToString(g_t0, TIME_DATE | TIME_MINUTES), dc);
      Row(x, y0, W, r++, rowH, "Tuzilma bilan mos", g_big ? "HA (BIG)" : "YO'Q", g_big ? cB : cN);
      Row(x, y0, W, r++, rowH, "Entry", Px(g_en), clrWhite);
      Row(x, y0, W, r++, rowH, "Stop Loss", Px(g_sl) + (g_hs ? "  X" : ""), clrOrange);
      Row(x, y0, W, r++, rowH, "TP1", Px(g_t1) + (g_h1 ? "  OK" : ""), cB);
      Row(x, y0, W, r++, rowH, "TP2", Px(g_t2) + (g_h2 ? "  OK" : ""), cB);
      Row(x, y0, W, r++, rowH, "TP3", Px(g_t3) + (g_h3 ? "  OK" : ""), cB);
      string hol = g_hs ? "SL urildi" : (g_h3 ? "TP3 - yopildi" : "OCHIQ");
      double risk = MathAbs(g_en - g_sl);
      if(active && risk > 0)
         hol += StringFormat("  %+.2fR", (bid - g_en) * g_dir / risk);
      Row(x, y0, W, r++, rowH, "Holat", hol, g_hs ? cS : cB);
     }
   else
      for(int k = 0; k < 8; k++)
         Row(x, y0, W, r++, rowH, k == 0 ? "Signal" : " ", "-", cN);
   Row(x, y0, W, r++, rowH, "---- TARIX (halol hisob) ----", "", cH);
   Row(x, y0, W, r++, rowH, "Signallar", StringFormat("%d (BIG %d)", g_signals, g_bigSignals), clrWhite);
   Row(x, y0, W, r++, rowH, "TP1 da chiqish", StatTxt(0), g_kR[0] >= 0 ? cB : cS);
   Row(x, y0, W, r++, rowH, "TP2 da chiqish", StatTxt(1), g_kR[1] >= 0 ? cB : cS);
   Row(x, y0, W, r++, rowH, "TP3 da chiqish", StatTxt(2), g_kR[2] >= 0 ? cB : cS);
  }

//==================================================================
int OnInit()
  {
   if(InpFastEMA < 1 || InpSlowEMA < 1 || InpATRLen < 1 || InpDepth < 2)
      return INIT_PARAMETERS_INCORRECT;
   SetIndexBuffer(0, gFast, INDICATOR_DATA);
   SetIndexBuffer(1, gSlow, INDICATOR_DATA);
   SetIndexBuffer(2, gAtr, INDICATOR_CALCULATIONS);
   SetIndexBuffer(3, gHighing, INDICATOR_CALCULATIONS);
   SetIndexBuffer(4, gLowing, INDICATOR_CALCULATIONS);
   SetIndexBuffer(5, gD1, INDICATOR_CALCULATIONS);
   SetIndexBuffer(6, gD2, INDICATOR_CALCULATIONS);
   SetIndexBuffer(7, gSig, INDICATOR_CALCULATIONS);
   SetIndexBuffer(8, gSLb, INDICATOR_CALCULATIONS);
   SetIndexBuffer(9, gTP1b, INDICATOR_CALCULATIONS);
   SetIndexBuffer(10, gTP2b, INDICATOR_CALCULATIONS);
   SetIndexBuffer(11, gTP3b, INDICATOR_CALCULATIONS);
   ArraySetAsSeries(gFast, false); ArraySetAsSeries(gSlow, false); ArraySetAsSeries(gAtr, false);
   ArraySetAsSeries(gHighing, false); ArraySetAsSeries(gLowing, false); ArraySetAsSeries(gD1, false);
   ArraySetAsSeries(gD2, false); ArraySetAsSeries(gSig, false); ArraySetAsSeries(gSLb, false);
   ArraySetAsSeries(gTP1b, false); ArraySetAsSeries(gTP2b, false); ArraySetAsSeries(gTP3b, false);
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   hFast = iMA(_Symbol, _Period, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlow = iMA(_Symbol, _Period, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   if(hFast == INVALID_HANDLE || hSlow == INVALID_HANDLE)
      return INIT_FAILED;
   IndicatorSetString(INDICATOR_SHORTNAME, "KN + LM");
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
   ResetState();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(!InpEAMode)
      ObjectsDeleteAll(0, PFX);
   if(hFast != INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow != INVALID_HANDLE) IndicatorRelease(hSlow);
  }

void CalcATR(const int from, const int rates_total, const double &high[], const double &low[], const double &close[])
  {
   int n = InpATRLen;
   for(int i = MathMax(0, from); i < rates_total; i++)
     {
      double tr = (i == 0) ? high[i] - low[i]
                  : MathMax(high[i] - low[i], MathMax(MathAbs(high[i] - close[i - 1]), MathAbs(low[i] - close[i - 1])));
      if(i < n)
        {
         double s = 0;
         for(int k = 0; k <= i; k++)
            s += (k == 0) ? high[k] - low[k]
                 : MathMax(high[k] - low[k], MathMax(MathAbs(high[k] - close[k - 1]), MathAbs(low[k] - close[k - 1])));
         gAtr[i] = s / (i + 1);
        }
      else
         gAtr[i] = (gAtr[i - 1] * (n - 1) + tr) / n;   // RMA (Wilder), as TradingView ta.atr
     }
  }

int OnCalculate(const int rates_total, const int prev_calculated, const datetime &time[], const double &open[],
                const double &high[], const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
  {
   int warm = MathMax(MathMax(InpSlowEMA, InpATRLen), InpDepth) + 5;
   if(rates_total < warm + 10)
      return 0;
   ArraySetAsSeries(time, false); ArraySetAsSeries(open, false); ArraySetAsSeries(high, false);
   ArraySetAsSeries(low, false);  ArraySetAsSeries(close, false);
   if(BarsCalculated(hFast) < rates_total || BarsCalculated(hSlow) < rates_total)
      return 0;

   bool full = (prev_calculated <= 0);
   if(!full && (g_lastIdx < 0 || g_lastIdx >= rates_total || time[g_lastIdx] != g_lastTime))
      full = true;
   int count = full ? rates_total : MathMin(rates_total, rates_total - prev_calculated + 2);
   if(!CopyInd(hFast, rates_total, count, gFast)) return 0;
   if(!CopyInd(hSlow, rates_total, count, gSlow)) return 0;
   CalcATR(full ? 0 : MathMax(0, prev_calculated - 2), rates_total, high, low, close);

   if(full)
     {
      if(!InpEAMode)
         ObjectsDeleteAll(0, PFX);
      ResetState();
      ArrayInitialize(gSig, 0); ArrayInitialize(gSLb, 0); ArrayInitialize(gTP1b, 0);
      ArrayInitialize(gTP2b, 0); ArrayInitialize(gTP3b, 0);
      ArrayInitialize(gHighing, 0); ArrayInitialize(gLowing, 0);
      ArrayInitialize(gD1, 0); ArrayInitialize(gD2, 0);
      g_lastIdx = MathMax(warm, rates_total - InpHistoryBars) - 1;
     }

   int lastClosed = rates_total - 2;
   for(int i = g_lastIdx + 1; i <= lastClosed; i++)
     {
      g_live = g_ready && (i == lastClosed);
      ZigzagBar(i, time, open, high, low, close);
      KNBar(i, time, high, low, close);
     }
   g_live = false;
   if(lastClosed > g_lastIdx)
     {
      g_lastIdx = lastClosed;
      g_lastTime = time[lastClosed];
     }
   gSig[rates_total - 1] = 0;

   if(!InpEAMode)
     {
      datetime tNow = time[rates_total - 1];
      for(int k = 0; k < ArraySize(g_hor); k++)
         if(InpExtendLines || InpUseBoxes)
            DrawHor(k, tNow);
      if(g_dir != 0)
        {
         datetime tEnd = ((g_hs || g_h3) && g_tFin > 0) ? g_tFin : tNow;
         tEnd += PeriodSeconds() * InpLabelOffset;
         DrawTrade(g_t0, tEnd);
        }
      DrawDashboard(rates_total, close);
      ChartRedraw();
     }
   g_ready = true;
   return rates_total;
  }
//+------------------------------------------------------------------+
