//+------------------------------------------------------------------+
//|                                          SMC_Structure_Pro.mq5   |
//|  Market Structure (HH/HL/LH/LL, BOS/CHoCH)                       |
//|  + Supply/Demand zonalar + EMA trend filtri                     |
//|  + BUY/SELL signal, Entry / SL / TP1-TP3                         |
//|  + professional dashbord (BIG BUY / BIG SELL) + ovozli signal     |
//|                                                                  |
//|  Signallar faqat YOPILGAN bar bo'yicha hisoblanadi (repaint yo'q).    |
//|  Bu savdo maslahati emas. Avval demo hisobda sinab ko'ring.        |
//+------------------------------------------------------------------+
#property copyright   "SMC Structure Pro (macOS)"
#property version     "1.00"
#property description "Market structure (HH/HL/LH/LL, BOS/CHoCH), supply/demand zones,"
#property description "EMA trend filter, BUY/SELL signals with Entry/SL/TP1-3,"
#property description "dashboard with BIG BUY / BIG SELL and sound/push/email alerts."
#property indicator_chart_window
#property indicator_buffers 12
#property indicator_plots   5

#property indicator_label1  "Fast EMA"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrLimeGreen
#property indicator_width1  2

#property indicator_label2  "Slow EMA"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrRed
#property indicator_width2  2

#property indicator_label3  "Trend MA"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrDodgerBlue
#property indicator_style3  STYLE_DOT
#property indicator_width3  1

#property indicator_label4  "BUY"
#property indicator_type4   DRAW_ARROW
#property indicator_color4  clrLimeGreen
#property indicator_width4  3

#property indicator_label5  "SELL"
#property indicator_type5   DRAW_ARROW
#property indicator_color5  clrRed
#property indicator_width5  3

#define PFX "SMCP_"

//==================================================================
// INPUTS
//==================================================================
input bool   InpEAMode         = false;  // EA rejimi (faqat sovetnik uchun, o'zgartirmang)

input group "=== Struktura (swing) ==="
input int    InpPivotLen       = 5;      // Swing (fractal) uzunligi, bar
input bool   InpShowLabels     = true;   // HH / HL / LH / LL yozuvlari
input bool   InpShowZigZag     = true;   // Swing chiziqlari (punktir)
input bool   InpShowBOS        = true;   // BOS / CHoCH chiziqlari
input bool   InpShowTrendlines = true;   // Trend chiziqlari (oxirgi 2 swing)

input group "=== Supply / Demand zonalar ==="
input bool   InpShowZones      = true;   // Zonalarni ko'rsatish
input int    InpMaxZones       = 4;      // Har tomonda eng ko'p faol zona
input double InpZoneMinATR     = 0.25;   // Zona minimal qalinligi (ATR)
input int    InpZoneLookback   = 8;      // Zonaga tegish: signalgacha necha bar ichida
input int    InpExtendBars     = 20;     // Zonalarni o'ngga uzaytirish (bar)

input group "=== Muvinglar va filtrlar ==="
input int            InpFastMA     = 9;        // Tez MA davri
input int            InpSlowMA     = 21;       // Sekin MA davri
input ENUM_MA_METHOD InpMAMethod   = MODE_EMA; // MA turi
input int            InpTrendMA    = 200;      // Trend filtri MA davri
input bool           InpShowTrendMA= true;     // Trend MA ni chizish
input int            InpRSIPeriod  = 14;       // RSI davri
input int            InpATRPeriod  = 14;       // ATR davri

input group "=== Signal ==="
input bool   InpUseCrossTrigger = true;  // Trigger: EMA kesishuvi
input bool   InpUseZoneTrigger  = true;  // Trigger: zonadan qaytish (rejection)
input int    InpMinScore        = 2;     // Signal uchun minimal ball (0-4)
input int    InpBigScore        = 4;     // BIG signal uchun ball (0-4)

input group "=== Entry / SL / TP ==="
input double InpSLBufferATR    = 0.20;   // SL: swing ortidan zaxira (ATR)
input double InpMinRiskATR     = 0.50;   // Minimal risk (ATR)
input double InpMaxRiskATR     = 3.00;   // Maksimal risk (ATR)
input double InpTP1_RR         = 1.0;    // TP1 (R:R)
input double InpTP2_RR         = 2.0;    // TP2 (R:R)
input double InpTP3_RR         = 3.0;    // TP3 (R:R)
input bool   InpBEafterTP1     = true;   // TP1 dan keyin SL -> Entry (bezubitok)
input int    InpMaxTradesDrawn = 30;     // Chartda saqlanadigan oxirgi savdolar soni
input color  InpRiskBoxColor   = C'255,222,222'; // Risk qutisi rangi
input color  InpRewardBoxColor = C'214,244,220'; // Foyda qutisi rangi

input group "=== Dashbord ==="
input bool   InpShowDash       = true;          // Dashbordni ko'rsatish
input int    InpDashX          = 12;            // X (chapdan)
input int    InpDashY          = 40;            // Y (yuqoridan)
input string InpFont           = "Arial";    // Shrift
input string InpFontBold       = "Arial"; // Qalin shrift
input int    InpFontSize       = 9;             // Shrift o'lchami
input double InpDashScale      = 0;             // Dashboard masshtabi (0 = avto, 1.0 / 1.5 / 2.0)
input color  InpDashBg         = C'18,24,38';   // Fon
input color  InpDashBorder     = C'60,75,110';  // Chegara
input color  InpDashText       = C'190,200,222';// Matn
input int    InpBlinkSeconds   = 30;            // BIG signalda banner miltillashi (sek)

input group "=== Ogohlantirish ==="
input bool   InpAlertPopup     = true;          // Alert oynasi
input bool   InpAlertSound     = true;          // Ovoz
input string InpSoundNormal    = "alert.wav";   // Oddiy signal ovozi
input string InpSoundBig       = "alert2.wav";  // BIG signal ovozi
input bool   InpAlertPush      = false;         // Push (MT5 mobil)
input bool   InpAlertEmail     = false;         // E-mail
input bool   InpAlertBigOnly   = false;         // Faqat BIG signallarda ogohlantirish
input bool   InpAlertTPSL      = true;          // TP / SL urilganda xabar

input group "=== Ranglar / tarix ==="
input int    InpHistoryBars    = 1500;          // Tarixda hisoblanadigan barlar
input color  InpBullColor      = C'0,160,90';   // Bull rangi
input color  InpBearColor      = C'220,40,60';  // Bear rangi
input color  InpDemandColor    = C'200,238,210';// Demand zona rangi
input color  InpSupplyColor    = C'255,208,214';// Supply zona rangi
input color  InpSwingColor     = clrGray;       // Swing chiziqlari rangi

//==================================================================
// BUFFERS / HANDLES
//==================================================================
double gFast[], gSlow[], gTrend[], gBuy[], gSell[], gRsi[], gAtr[];
double gSig[], gSLb[], gTP1b[], gTP2b[], gTP3b[];
int hFast = INVALID_HANDLE, hSlow = INVALID_HANDLE, hTrend = INVALID_HANDLE;
int hRsi  = INVALID_HANDLE, hAtr  = INVALID_HANDLE;

//==================================================================
// STATE
//==================================================================
struct SZone
  {
   int      type;   // +1 demand, -1 supply
   double   top;
   double   bot;
   datetime t0;
   int      born;   // bar indeksi (shu bardan keyin tekshiriladi)
  };
SZone g_z[];

struct STrade
  {
   int      id;
   int      dir;     // +1 buy, -1 sell
   int      score;
   bool     big;
   bool     active;
   bool     hit1;
   bool     hit2;
   bool     hit3;
   bool     slHit;
   bool     beHit;
   datetime t0;
   datetime t1;
   double   entry;
   double   sl;
   double   curSL;
   double   tp1;
   double   tp2;
   double   tp3;
  };
STrade g_tr;
string g_trStatus = "-";

double   g_hiPrice, g_prevHiPrice, g_loPrice, g_prevLoPrice;
datetime g_hiTime,  g_prevHiTime,  g_loTime,  g_prevLoTime;
bool     g_hiBroken, g_loBroken;
int      g_struct;                 // +1 bullish, -1 bearish, 0 neutral
string   g_lastBOS, g_lastSwing;
double   g_lastSwingPrice;
datetime g_lastPivTime;
double   g_lastPivPrice;
int      g_demTouch, g_supTouch;

int      g_tradeId, g_signals, g_wins, g_losses;
bool     g_ready, g_live;
int      g_lastIdx;
datetime g_lastTime;

datetime g_blinkUntil = 0;
bool     g_blinkOn    = false;
color    g_banBg      = C'45,55,80';
color    g_banBgAlt   = C'45,55,80';

//==================================================================
// HELPERS
//==================================================================
string TFStr() { return StringSubstr(EnumToString((ENUM_TIMEFRAMES)_Period), 7); }
string Px(const double v) { return DoubleToString(v, _Digits); }

string Stars(const int s)
  {
   string r = "";
   for(int k = 0; k < 4; k++)
      r += (k < s) ? "*" : ".";
   return r;
  }

void MkText(const string name, const datetime t, const double p, const string txt,
            const color c, const int fs, const ENUM_ANCHOR_POINT anc)
  {
   if(InpEAMode) return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TEXT, 0, t, p);
   else
      ObjectMove(0, name, 0, t, p);
   ObjectSetString(0, name, OBJPROP_TEXT, txt);
   ObjectSetString(0, name, OBJPROP_FONT, InpFontBold);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anc);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
  }

void MkTrend(const string name, const datetime t1, const double p1, const datetime t2, const double p2,
             const color c, const ENUM_LINE_STYLE st, const int w, const bool ray)
  {
   if(InpEAMode) return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, p1, t2, p2);
   else
     {
      ObjectMove(0, name, 0, t1, p1);
      ObjectMove(0, name, 1, t2, p2);
     }
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_STYLE, st);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, w);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, ray);
   ObjectSetInteger(0, name, OBJPROP_RAY_LEFT, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
  }

void MkRect(const string name, const datetime t1, const double p1, const datetime t2, const double p2, const color c)
  {
   if(InpEAMode) return;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_RECTANGLE, 0, t1, p1, t2, p2);
   else
     {
      ObjectMove(0, name, 0, t1, p1);
      ObjectMove(0, name, 1, t2, p2);
     }
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
   ObjectSetInteger(0, name, OBJPROP_FILL, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
  }

void DashRect(const string name, const int x, const int y, const int w, const int h, const color bg, const color border)
  {
   if(InpEAMode) return;
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetInteger(0, name, OBJPROP_BACK, false);
     }
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, name, OBJPROP_COLOR, border);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
  }

void DashLabel(const string name, const int x, const int y, const string text, const color c,
               const int fs, const string font, const ENUM_ANCHOR_POINT anc)
  {
   if(InpEAMode) return;
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetInteger(0, name, OBJPROP_BACK, false);
     }
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anc);
   ObjectSetString(0, name, OBJPROP_TEXT, (text == "") ? " " : text);
   ObjectSetString(0, name, OBJPROP_FONT, font);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, name, OBJPROP_COLOR, c);
  }

bool CopyInd(const int handle, const int rates_total, const int count, double &dst[])
  {
   double tmp[];
   ArraySetAsSeries(tmp, true);
   int got = CopyBuffer(handle, 0, 0, count, tmp);
   if(got <= 0)
      return false;
   for(int k = 0; k < got; k++)
      dst[rates_total - 1 - k] = tmp[k];
   return true;
  }

//==================================================================
// STATE RESET
//==================================================================
void ResetTrade()
  {
   g_tr.id = 0;  g_tr.dir = 0; g_tr.score = 0;
   g_tr.big = false; g_tr.active = false;
   g_tr.hit1 = false; g_tr.hit2 = false; g_tr.hit3 = false;
   g_tr.slHit = false; g_tr.beHit = false;
   g_tr.t0 = 0; g_tr.t1 = 0;
   g_tr.entry = 0; g_tr.sl = 0; g_tr.curSL = 0;
   g_tr.tp1 = 0; g_tr.tp2 = 0; g_tr.tp3 = 0;
   g_trStatus = "-";
  }

void ResetState()
  {
   ArrayResize(g_z, 0);
   g_hiPrice = 0; g_prevHiPrice = 0; g_loPrice = 0; g_prevLoPrice = 0;
   g_hiTime  = 0; g_prevHiTime  = 0; g_loTime  = 0; g_prevLoTime  = 0;
   g_hiBroken = false; g_loBroken = false;
   g_struct = 0;
   g_lastBOS = "-"; g_lastSwing = "-"; g_lastSwingPrice = 0;
   g_lastPivTime = 0; g_lastPivPrice = 0;
   g_demTouch = -1; g_supTouch = -1;
   g_tradeId = 0; g_signals = 0; g_wins = 0; g_losses = 0;
   g_ready = false; g_live = false;
   g_lastIdx = -1; g_lastTime = 0;
   ResetTrade();
  }

//==================================================================
// ZONES
//==================================================================
string ZoneName(const int k)
  {
   return PFX + "ZN_" + (g_z[k].type > 0 ? "D_" : "S_") + (string)(long)g_z[k].t0;
  }

void RemoveZone(const int k)
  {
   ObjectDelete(0, ZoneName(k));
   int n = ArraySize(g_z);
   for(int j = k; j < n - 1; j++)
      g_z[j] = g_z[j + 1];
   ArrayResize(g_z, n - 1);
  }

void AddZone(const int type, const double top, const double bot, const datetime t0, const int born)
  {
   if(!InpShowZones)
      return;
   int n = ArraySize(g_z);
   // bir xil turdagi kesishgan zona bo'lsa - yangisini qo'shmaymiz
   for(int k = 0; k < n; k++)
      if(g_z[k].type == type && bot <= g_z[k].top && top >= g_z[k].bot)
         return;
   int maxZ = MathMax(1, InpMaxZones);
   int cnt = 0, oldest = -1;
   for(int k = 0; k < n; k++)
      if(g_z[k].type == type)
        {
         cnt++;
         if(oldest < 0)
            oldest = k;
        }
   if(cnt >= maxZ && oldest >= 0)
      RemoveZone(oldest);
   n = ArraySize(g_z);
   ArrayResize(g_z, n + 1);
   g_z[n].type = type;
   g_z[n].top  = top;
   g_z[n].bot  = bot;
   g_z[n].t0   = t0;
   g_z[n].born = born;
   MkRect(ZoneName(n), t0, top, t0 + PeriodSeconds() * InpExtendBars, bot,
          type > 0 ? InpDemandColor : InpSupplyColor);
  }

void ExtendZones(const datetime tEnd)
  {
   int n = ArraySize(g_z);
   for(int k = 0; k < n; k++)
      ObjectMove(0, ZoneName(k), 1, tEnd, g_z[k].bot);
  }

//==================================================================
// ALERTS
//==================================================================
void Notify(const string msg, const string sound)
  {
   if(InpEAMode) return;
   if(InpAlertPopup)
      Alert(msg);
   if(InpAlertSound && sound != "")
      PlaySound(sound);
   if(InpAlertPush)
      SendNotification(msg);
   if(InpAlertEmail)
      SendMail("SMC Pro: " + _Symbol + " " + TFStr(), msg);
  }

//==================================================================
// TRADE DRAWING
//==================================================================
string TPText(const string nm, const double p, const bool hit)
  {
   return nm + " " + Px(p) + (hit ? "  OK" : "");
  }

void DrawTrade(const datetime tEnd)
  {
   if(g_tr.id <= 0)
      return;
   string b = PFX + "T" + (string)g_tr.id + "_";
   datetime t0 = g_tr.t0;
   MkRect(b + "RISK", t0, g_tr.entry, tEnd, g_tr.sl,  InpRiskBoxColor);
   MkRect(b + "REW",  t0, g_tr.entry, tEnd, g_tr.tp3, InpRewardBoxColor);

   MkTrend(b + "L_EN", t0, g_tr.entry, tEnd, g_tr.entry, clrDimGray,   STYLE_SOLID, 1, false);
   MkTrend(b + "L_SL", t0, g_tr.sl,    tEnd, g_tr.sl,    clrOrangeRed, STYLE_SOLID, 2, false);
   MkTrend(b + "L_T1", t0, g_tr.tp1,   tEnd, g_tr.tp1,   InpBullColor, STYLE_DOT,   1, false);
   MkTrend(b + "L_T2", t0, g_tr.tp2,   tEnd, g_tr.tp2,   InpBullColor, STYLE_DOT,   1, false);
   MkTrend(b + "L_T3", t0, g_tr.tp3,   tEnd, g_tr.tp3,   InpBullColor, STYLE_SOLID, 1, false);

   int fs = InpFontSize - 1;
   string slTxt = "SL " + Px(g_tr.sl) + (g_tr.slHit ? "  X" : (g_tr.beHit ? "  BE" : ""));
   MkText(b + "X_EN", tEnd, g_tr.entry, "ENTRY " + Px(g_tr.entry), clrDimGray, fs, ANCHOR_LEFT);
   MkText(b + "X_SL", tEnd, g_tr.sl,    slTxt, clrOrangeRed, fs, ANCHOR_LEFT);
   MkText(b + "X_T1", tEnd, g_tr.tp1,   TPText("TP1", g_tr.tp1, g_tr.hit1), InpBullColor, fs, ANCHOR_LEFT);
   MkText(b + "X_T2", tEnd, g_tr.tp2,   TPText("TP2", g_tr.tp2, g_tr.hit2), InpBullColor, fs, ANCHOR_LEFT);
   MkText(b + "X_T3", tEnd, g_tr.tp3,   TPText("TP3", g_tr.tp3, g_tr.hit3), InpBullColor, fs, ANCHOR_LEFT);
  }

void CloseTrade(const datetime t, const string reason)
  {
   g_tr.active = false;
   g_tr.t1 = t;
   g_trStatus = reason;
   DrawTrade(t);
  }

void ManageTrade(const int i, const datetime &time[], const double &high[], const double &low[])
  {
   if(!g_tr.active || g_tr.t0 >= time[i])
      return;
   int d = g_tr.dir;
   string sig = (d > 0 ? "BUY" : "SELL");
   // 1) SL (konservativ: bir barda ikkalasi bo'lsa avval SL)
   bool slTouched = (d > 0) ? (low[i] <= g_tr.curSL) : (high[i] >= g_tr.curSL);
   if(slTouched)
     {
      if(g_tr.hit1)
        {
         g_tr.beHit = true;
         CloseTrade(time[i], "TP1 dan keyin BE da yopildi");
        }
      else
        {
         g_tr.slHit = true;
         g_losses++;
         CloseTrade(time[i], "SL X");
        }
      if(g_live && InpAlertTPSL)
         Notify(StringFormat("SMC Pro %s %s: %s - %s", _Symbol, TFStr(), sig, g_trStatus), "stops.wav");
      return;
     }
   // 2) TP lar
   bool changed = false;
   string ev = "";
   if(!g_tr.hit1 && ((d > 0) ? high[i] >= g_tr.tp1 : low[i] <= g_tr.tp1))
     {
      g_tr.hit1 = true; g_wins++; changed = true; ev = "TP1 OK";
      if(InpBEafterTP1)
         g_tr.curSL = g_tr.entry;
     }
   if(g_tr.hit1 && !g_tr.hit2 && ((d > 0) ? high[i] >= g_tr.tp2 : low[i] <= g_tr.tp2))
     {
      g_tr.hit2 = true; changed = true; ev = "TP2 OK";
     }
   if(g_tr.hit2 && !g_tr.hit3 && ((d > 0) ? high[i] >= g_tr.tp3 : low[i] <= g_tr.tp3))
     {
      g_tr.hit3 = true; changed = true; ev = "TP3 OK";
     }
   if(!changed)
      return;
   if(g_tr.hit3)
      CloseTrade(time[i], "TP3 OK - to'liq yopildi");
   else
     {
      g_trStatus = ev + (g_tr.hit1 && InpBEafterTP1 ? " (SL=BE)" : "");
      DrawTrade(time[i]);
     }
   if(g_live && InpAlertTPSL)
      Notify(StringFormat("SMC Pro %s %s: %s - %s", _Symbol, TFStr(), sig, ev), "ok.wav");
  }

//==================================================================
// SIGNAL
//==================================================================
int CalcScore(const int dir, const int i, const double &close[])
  {
   int score = 0;
   // 1) Bozor strukturasi (BOS/CHoCH) yo'nalishi
   if(g_struct == dir)
      score++;
   // 2) Trend MA filtri
   double tma = gTrend[i];
   if(tma != EMPTY_VALUE && tma > 0)
      if((dir > 0 && close[i] > tma) || (dir < 0 && close[i] < tma))
         score++;
   // 3) Yaqinda demand/supply zonasiga tegish
   int touch = (dir > 0) ? g_demTouch : g_supTouch;
   if(touch >= 0 && i - touch <= InpZoneLookback)
      score++;
   // 4) RSI momentum (haddan tashqari bo'lmagan)
   double r = gRsi[i];
   if(r != EMPTY_VALUE)
      if((dir > 0 && r > 50.0 && r < 70.0) || (dir < 0 && r < 50.0 && r > 30.0))
         score++;
   return score;
  }

void OpenSignal(const int dir, const int i, const double atr, const datetime &time[],
                const double &high[], const double &low[], const double &close[])
  {
   if(g_tr.active && g_tr.dir == dir)
      return;                                   // shu yo'nalishda savdo ochiq
   int score = CalcScore(dir, i, close);
   if(score < InpMinScore)
      return;
   bool big = (score >= InpBigScore);

   if(g_tr.active)
      CloseTrade(time[i], "Teskari signal bilan yopildi");

   // stariy treyd ob'ektlarini cheklash
   g_tradeId++;
   if(InpMaxTradesDrawn > 0 && g_tradeId - InpMaxTradesDrawn > 0)
      ObjectsDeleteAll(0, PFX + "T" + (string)(g_tradeId - InpMaxTradesDrawn) + "_");

   double entry = close[i];
   double risk;
   if(dir > 0)
     {
      double sl0 = (g_loPrice > 0 && g_loPrice < entry) ? g_loPrice - atr * InpSLBufferATR : entry - atr * 1.5;
      risk = entry - sl0;
     }
   else
     {
      double sl0 = (g_hiPrice > 0 && g_hiPrice > entry) ? g_hiPrice + atr * InpSLBufferATR : entry + atr * 1.5;
      risk = sl0 - entry;
     }
   risk = MathMax(risk, atr * InpMinRiskATR);
   risk = MathMin(risk, atr * InpMaxRiskATR);
   if(risk <= 0)
      risk = atr;

   ResetTrade();
   g_tr.id     = g_tradeId;
   g_tr.dir    = dir;
   g_tr.score  = score;
   g_tr.big    = big;
   g_tr.active = true;
   g_tr.t0     = time[i];
   g_tr.entry  = entry;
   g_tr.sl     = NormalizeDouble(entry - dir * risk, _Digits);
   g_tr.curSL  = g_tr.sl;
   g_tr.tp1    = NormalizeDouble(entry + dir * risk * InpTP1_RR, _Digits);
   g_tr.tp2    = NormalizeDouble(entry + dir * risk * InpTP2_RR, _Digits);
   g_tr.tp3    = NormalizeDouble(entry + dir * risk * InpTP3_RR, _Digits);
   g_trStatus  = "ACTIVE";
   g_signals++;
   gSig[i] = dir * (big ? 2 : 1); gSLb[i] = g_tr.sl; gTP1b[i] = g_tr.tp1; gTP2b[i] = g_tr.tp2; gTP3b[i] = g_tr.tp3;

   string txt = big ? (dir > 0 ? "BIG BUY" : "BIG SELL") : (dir > 0 ? "BUY" : "SELL");
   string b = PFX + "T" + (string)g_tr.id + "_";
   if(dir > 0)
     {
      gBuy[i] = low[i] - atr * 0.3;
      MkText(b + "SG", time[i], low[i] - atr * 0.8, txt, InpBullColor, big ? InpFontSize + 3 : InpFontSize, ANCHOR_UPPER);
     }
   else
     {
      gSell[i] = high[i] + atr * 0.3;
      MkText(b + "SG", time[i], high[i] + atr * 0.8, txt, InpBearColor, big ? InpFontSize + 3 : InpFontSize, ANCHOR_LOWER);
     }
   DrawTrade(time[i] + PeriodSeconds() * 8);

   if(g_live && (!InpAlertBigOnly || big))
     {
      string msg = StringFormat("SMC Pro %s %s: %s @ %s | SL %s | TP1 %s | TP2 %s | TP3 %s | Ball %d/4",
                                _Symbol, TFStr(), txt, Px(g_tr.entry), Px(g_tr.sl),
                                Px(g_tr.tp1), Px(g_tr.tp2), Px(g_tr.tp3), score);
      Notify(msg, big ? InpSoundBig : InpSoundNormal);
     }
   if(g_live && big)
      g_blinkUntil = TimeLocal() + InpBlinkSeconds;
  }

//==================================================================
// STRUCTURE
//==================================================================
bool IsPivotHigh(const int p, const double &high[])
  {
   for(int k = 1; k <= InpPivotLen; k++)
     {
      if(high[p - k] >= high[p])
         return false;
      if(high[p + k] > high[p])
         return false;
     }
   return true;
  }

bool IsPivotLow(const int p, const double &low[])
  {
   for(int k = 1; k <= InpPivotLen; k++)
     {
      if(low[p - k] <= low[p])
         return false;
      if(low[p + k] < low[p])
         return false;
     }
   return true;
  }

void OnPivotHigh(const int p, const int i, const double atr, const datetime &time[],
                 const double &open[], const double &high[], const double &close[])
  {
   double   price = high[p];
   datetime t     = time[p];
   string   tag   = "";
   if(g_hiPrice > 0)
      tag = (price > g_hiPrice) ? "HH" : "LH";
   if(InpShowLabels && tag != "")
      MkText(PFX + "PV_H_" + (string)(long)t, t, price, tag,
             tag == "HH" ? InpBullColor : InpBearColor, InpFontSize, ANCHOR_LOWER);
   if(InpShowZigZag && g_lastPivTime > 0)
      MkTrend(PFX + "ZZ_H_" + (string)(long)t, g_lastPivTime, g_lastPivPrice, t, price, InpSwingColor, STYLE_DASH, 1, false);

   g_prevHiPrice = g_hiPrice; g_prevHiTime = g_hiTime;
   g_hiPrice = price; g_hiTime = t; g_hiBroken = false;
   g_lastPivTime = t; g_lastPivPrice = price;
   g_lastSwing = (tag == "") ? "H" : tag; g_lastSwingPrice = price;

   if(InpShowTrendlines && g_prevHiTime > 0)
      MkTrend(PFX + "TL_H", g_prevHiTime, g_prevHiPrice, t, price, InpBearColor, STYLE_DASH, 1, true);

   // Supply zona: pivot shamning yuqori qismi (fitil + tana)
   double bodyTop = MathMax(open[p], close[p]);
   double bot = MathMin(bodyTop, price - atr * InpZoneMinATR);
   AddZone(-1, price, bot, t, i);
  }

void OnPivotLow(const int p, const int i, const double atr, const datetime &time[],
                const double &open[], const double &low[], const double &close[])
  {
   double   price = low[p];
   datetime t     = time[p];
   string   tag   = "";
   if(g_loPrice > 0)
      tag = (price > g_loPrice) ? "HL" : "LL";
   if(InpShowLabels && tag != "")
      MkText(PFX + "PV_L_" + (string)(long)t, t, price, tag,
             tag == "HL" ? InpBullColor : InpBearColor, InpFontSize, ANCHOR_UPPER);
   if(InpShowZigZag && g_lastPivTime > 0)
      MkTrend(PFX + "ZZ_L_" + (string)(long)t, g_lastPivTime, g_lastPivPrice, t, price, InpSwingColor, STYLE_DASH, 1, false);

   g_prevLoPrice = g_loPrice; g_prevLoTime = g_loTime;
   g_loPrice = price; g_loTime = t; g_loBroken = false;
   g_lastPivTime = t; g_lastPivPrice = price;
   g_lastSwing = (tag == "") ? "L" : tag; g_lastSwingPrice = price;

   if(InpShowTrendlines && g_prevLoTime > 0)
      MkTrend(PFX + "TL_L", g_prevLoTime, g_prevLoPrice, t, price, InpBullColor, STYLE_DASH, 1, true);

   // Demand zona: pivot shamning pastki qismi
   double bodyBot = MathMin(open[p], close[p]);
   double top = MathMax(bodyBot, price + atr * InpZoneMinATR);
   AddZone(1, top, price, t, i);
  }

void CheckBOS(const int i, const datetime &time[], const double &close[])
  {
   if(g_hiPrice > 0 && !g_hiBroken && close[i] > g_hiPrice)
     {
      g_hiBroken = true;
      string lbl = (g_struct < 0) ? "CHoCH" : "BOS";
      g_struct = 1;
      g_lastBOS = lbl + " ^ " + Px(g_hiPrice);
      if(InpShowBOS)
        {
         string id = (string)(long)time[i];
         MkTrend(PFX + "BOSU_" + id, g_hiTime, g_hiPrice, time[i], g_hiPrice, InpBullColor, STYLE_DOT, 1, false);
         datetime mid = (datetime)(g_hiTime + (time[i] - g_hiTime) / 2);
         MkText(PFX + "BOSUT_" + id, mid, g_hiPrice, lbl, InpBullColor, InpFontSize - 2, ANCHOR_LOWER);
        }
     }
   if(g_loPrice > 0 && !g_loBroken && close[i] < g_loPrice)
     {
      g_loBroken = true;
      string lbl = (g_struct > 0) ? "CHoCH" : "BOS";
      g_struct = -1;
      g_lastBOS = lbl + " v " + Px(g_loPrice);
      if(InpShowBOS)
        {
         string id = (string)(long)time[i];
         MkTrend(PFX + "BOSD_" + id, g_loTime, g_loPrice, time[i], g_loPrice, InpBearColor, STYLE_DOT, 1, false);
         datetime mid = (datetime)(g_loTime + (time[i] - g_loTime) / 2);
         MkText(PFX + "BOSDT_" + id, mid, g_loPrice, lbl, InpBearColor, InpFontSize - 2, ANCHOR_UPPER);
        }
     }
  }

void UpdateZonesOnBar(const int i, const double &high[], const double &low[], const double &close[])
  {
   for(int k = ArraySize(g_z) - 1; k >= 0; k--)
     {
      if(g_z[k].born >= i)
         continue;
      if(g_z[k].type > 0)
        {
         if(close[i] < g_z[k].bot)      { RemoveZone(k); continue; }  // demand buzildi
         if(low[i] <= g_z[k].top)        g_demTouch = i;
        }
      else
        {
         if(close[i] > g_z[k].top)      { RemoveZone(k); continue; }  // supply buzildi
         if(high[i] >= g_z[k].bot)       g_supTouch = i;
        }
     }
  }

//==================================================================
// ONE CLOSED BAR
//==================================================================
void ProcessBar(const int i, const datetime &time[], const double &open[],
                const double &high[], const double &low[], const double &close[])
  {
   gBuy[i]  = EMPTY_VALUE;
   gSig[i] = 0; gSLb[i] = 0; gTP1b[i] = 0; gTP2b[i] = 0; gTP3b[i] = 0;
   gSell[i] = EMPTY_VALUE;

   double atr = gAtr[i];
   if(atr == EMPTY_VALUE || atr <= 0)
      atr = high[i] - low[i];
   if(atr <= 0)
      atr = _Point * 10;

   // 1) Swing pivotlar (PivotLen bar keyin tasdiqlanadi)
   int p = i - InpPivotLen;
   if(p - InpPivotLen >= 0)
     {
      if(IsPivotHigh(p, high))
         OnPivotHigh(p, i, atr, time, open, high, close);
      if(IsPivotLow(p, low))
         OnPivotLow(p, i, atr, time, open, low, close);
     }
   // 2) BOS / CHoCH
   CheckBOS(i, time, close);
   // 3) Zonalar: buzilish / tegish
   UpdateZonesOnBar(i, high, low, close);
   // 4) Ochiq savdo: TP/SL
   ManageTrade(i, time, high, low);
   // 5) Yangi signal
   if(i < 1)
      return;
   if(gFast[i] == EMPTY_VALUE || gSlow[i] == EMPTY_VALUE || gFast[i - 1] == EMPTY_VALUE || gSlow[i - 1] == EMPTY_VALUE)
      return;
   bool crossUp = InpUseCrossTrigger && gFast[i - 1] <= gSlow[i - 1] && gFast[i] > gSlow[i];
   bool crossDn = InpUseCrossTrigger && gFast[i - 1] >= gSlow[i - 1] && gFast[i] < gSlow[i];
   bool rejUp   = InpUseZoneTrigger && g_demTouch == i && close[i] > open[i] && close[i] > gFast[i] && g_struct >= 0;
   bool rejDn   = InpUseZoneTrigger && g_supTouch == i && close[i] < open[i] && close[i] < gFast[i] && g_struct <= 0;
   bool up = crossUp || rejUp;
   bool dn = crossDn || rejDn;
   if(up && dn)
      return;
   if(up)
      OpenSignal(1, i, atr, time, high, low, close);
   else
      if(dn)
         OpenSignal(-1, i, atr, time, high, low, close);
  }

//==================================================================
// DASHBOARD
//==================================================================
double g_sc = 1.0;
int S(const int v) { return (int)MathRound(v * g_sc); }

void CalcScale()
  {
   if(InpDashScale > 0)
     {
      g_sc = InpDashScale;
      return;
     }
   double dpi = (double)TerminalInfoInteger(TERMINAL_SCREEN_DPI);
   g_sc = (dpi > 0) ? dpi / 96.0 : 1.0;
   uint tw = 0, th = 0;
   if(TextSetFont(InpFont, -InpFontSize * 10) && TextGetSize("Struktura trendi", tw, th) && th > 0)
     {
      double m = th / (InpFontSize * 1.45);
      if(m > g_sc)
         g_sc = m;
     }
   if(g_sc < 1.0)
      g_sc = 1.0;
   if(g_sc > 3.0)
      g_sc = 3.0;
  }

void Row(const int x, const int y0, const int W, const int r, const int rowH,
         const string key, const string val, const color vc)
  {
   int yy = y0 + r * rowH;
   DashLabel(PFX + "D_K" + (string)r, x + S(10), yy, key, InpDashText, InpFontSize, InpFont, ANCHOR_LEFT_UPPER);
   DashLabel(PFX + "D_V" + (string)r, x + W - S(10), yy, val, vc, InpFontSize, InpFontBold, ANCHOR_RIGHT_UPPER);
  }

void DrawDashboard(const int rates_total, const double &close[])
  {
   if(InpEAMode) return;
   if(!InpShowDash)
      return;
   int c = rates_total - 2;
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(bid <= 0)
      bid = close[rates_total - 1];

   CalcScale();
   int x = S(InpDashX), y = S(InpDashY), W = S(310);
   int rowH = S(InpFontSize + 8);
   int nRows = 19;
   int bannerY = y + S(32), bannerH = S(34);
   int y0 = bannerY + bannerH + S(8);
   int H = (y0 - y) + nRows * rowH + S(8);

   color cBull = InpBullColor, cBear = InpBearColor, cNeu = C'150,160,180', cHead = C'255,200,80';

   DashRect(PFX + "D_BG",  x, y, W, H, InpDashBg, InpDashBorder);
   DashRect(PFX + "D_HDR", x, y, W, S(26), C'28,38,62', InpDashBorder);
   DashLabel(PFX + "D_T1", x + S(10), y + S(5), "SMC PRO", clrWhite, InpFontSize + 1, InpFontBold, ANCHOR_LEFT_UPPER);
   DashLabel(PFX + "D_T2", x + W - S(10), y + S(6), _Symbol + " | " + TFStr(), cHead, InpFontSize + 1, InpFontBold, ANCHOR_RIGHT_UPPER);

   // ---- Banner: BIG BUY / BIG SELL
   string banTxt;
   if(g_tr.active && g_tr.big)
     {
      banTxt     = (g_tr.dir > 0) ? "^  BIG BUY  ^" : "v  BIG SELL  v";
      g_banBg    = (g_tr.dir > 0) ? C'0,140,75'  : C'190,25,45';
      g_banBgAlt = (g_tr.dir > 0) ? C'0,215,115' : C'255,70,90';
     }
   else
      if(g_tr.active)
        {
         banTxt     = (g_tr.dir > 0) ? "BUY  " : "SELL  ";
         banTxt    += Stars(g_tr.score);
         g_banBg    = (g_tr.dir > 0) ? C'20,85,55' : C'105,30,40';
         g_banBgAlt = g_banBg;
        }
      else
        {
         banTxt     = "SIGNAL KUTILMOQDA";
         g_banBg    = C'45,55,80';
         g_banBgAlt = g_banBg;
        }
   bool blinking = (TimeLocal() < g_blinkUntil);
   DashRect(PFX + "D_BAN", x + S(6), bannerY, W - S(12), bannerH, (blinking && g_blinkOn) ? g_banBgAlt : g_banBg, InpDashBorder);
   DashLabel(PFX + "D_BANT", x + W / 2, bannerY + bannerH / 2, banTxt, clrWhite, InpFontSize + 3, InpFontBold, ANCHOR_CENTER);

   // ---- Market info
   string trTxt = (g_struct > 0) ? "^ BULLISH" : (g_struct < 0 ? "v BEARISH" : "- NEUTRAL");
   color  trCol = (g_struct > 0) ? cBull : (g_struct < 0 ? cBear : cNeu);

   bool   maUp  = (gFast[c] > gSlow[c]);
   string maTxt = maUp ? "^ Fast > Slow" : "v Fast < Slow";
   double tma   = gTrend[c];
   bool   aboveT = (tma != EMPTY_VALUE && close[c] > tma);
   string tTxt  = (tma == EMPTY_VALUE) ? "-" : (aboveT ? "^ narx ustida" : "v narx ostida");

   double rsi = gRsi[c], atr = gAtr[c];
   string zTxt = "-";
   color  zCol = cNeu;
   for(int k = 0; k < ArraySize(g_z); k++)
      if(bid <= g_z[k].top && bid >= g_z[k].bot)
        {
         zTxt = (g_z[k].type > 0) ? "DEMAND zonada" : "SUPPLY zonada";
         zCol = (g_z[k].type > 0) ? cBull : cBear;
         break;
        }

   int r = 0;
   Row(x, y0, W, r++, rowH, "Narx (Bid)",           Px(bid), clrWhite);
   Row(x, y0, W, r++, rowH, "Struktura trendi",     trTxt, trCol);
   Row(x, y0, W, r++, rowH, "Oxirgi BOS/CHoCH",     g_lastBOS, trCol);
   Row(x, y0, W, r++, rowH, "Oxirgi swing",         g_lastSwing + (g_lastSwingPrice > 0 ? "  " + Px(g_lastSwingPrice) : ""),
       (g_lastSwing == "HH" || g_lastSwing == "HL") ? cBull : ((g_lastSwing == "LH" || g_lastSwing == "LL") ? cBear : cNeu));
   Row(x, y0, W, r++, rowH, StringFormat("EMA %d / %d", InpFastMA, InpSlowMA), maTxt, maUp ? cBull : cBear);
   Row(x, y0, W, r++, rowH, StringFormat("MA %d filtri", InpTrendMA), tTxt, aboveT ? cBull : cBear);
   Row(x, y0, W, r++, rowH, StringFormat("RSI (%d)", InpRSIPeriod), (rsi == EMPTY_VALUE ? "-" : DoubleToString(rsi, 1)),
       rsi >= 70 ? cBear : (rsi <= 30 ? cBull : clrWhite));
   Row(x, y0, W, r++, rowH, StringFormat("ATR (%d)", InpATRPeriod), (atr == EMPTY_VALUE ? "-" : Px(atr)), clrWhite);
   Row(x, y0, W, r++, rowH, "Zona",                 zTxt, zCol);
   Row(x, y0, W, r++, rowH, "---- SIGNAL ----", "", cHead);

   if(g_tr.id > 0)
     {
      color dc = (g_tr.dir > 0) ? cBull : cBear;
      string sTxt = (g_tr.big ? "BIG " : "") + (g_tr.dir > 0 ? "BUY" : "SELL") + "  " + TimeToString(g_tr.t0, TIME_DATE | TIME_MINUTES);
      Row(x, y0, W, r++, rowH, "Signal",   sTxt, dc);
      Row(x, y0, W, r++, rowH, "Kuchi",     Stars(g_tr.score) + StringFormat("  %d/4", g_tr.score), cHead);
      Row(x, y0, W, r++, rowH, "Entry",    Px(g_tr.entry), clrWhite);
      Row(x, y0, W, r++, rowH, "Stop Loss", Px(g_tr.sl) + (g_tr.slHit ? "  X" : (g_tr.beHit ? "  BE" : "")), clrOrangeRed);
      Row(x, y0, W, r++, rowH, StringFormat("TP1 (1:%.1f)", InpTP1_RR), TPText("", g_tr.tp1, g_tr.hit1), cBull);
      Row(x, y0, W, r++, rowH, StringFormat("TP2 (1:%.1f)", InpTP2_RR), TPText("", g_tr.tp2, g_tr.hit2), cBull);
      Row(x, y0, W, r++, rowH, StringFormat("TP3 (1:%.1f)", InpTP3_RR), TPText("", g_tr.tp3, g_tr.hit3), cBull);
      string st = g_trStatus;
      color  sc = clrWhite;
      if(g_tr.active)
        {
         double risk = MathAbs(g_tr.entry - g_tr.sl);
         double rr = (risk > 0) ? (bid - g_tr.entry) * g_tr.dir / risk : 0;
         st = g_trStatus + StringFormat("  %+.2fR", rr);
         sc = (rr >= 0) ? cBull : cBear;
        }
      Row(x, y0, W, r++, rowH, "Holat", st, sc);
     }
   else
     {
      Row(x, y0, W, r++, rowH, "Signal",    "-", cNeu);
      Row(x, y0, W, r++, rowH, "Kuchi",      "-", cNeu);
      Row(x, y0, W, r++, rowH, "Entry",     "-", cNeu);
      Row(x, y0, W, r++, rowH, "Stop Loss", "-", cNeu);
      Row(x, y0, W, r++, rowH, "TP1",       "-", cNeu);
      Row(x, y0, W, r++, rowH, "TP2",       "-", cNeu);
      Row(x, y0, W, r++, rowH, "TP3",       "-", cNeu);
      Row(x, y0, W, r++, rowH, "Holat",     "-", cNeu);
     }
   int closed = g_wins + g_losses;
   string stat = StringFormat("%d sig | %d / %d", g_signals, g_wins, g_losses);
   if(closed > 0)
      stat += StringFormat(" (%.0f%%)", 100.0 * g_wins / closed);
   Row(x, y0, W, r++, rowH, "Tarix (TP1/SL)", stat, C'170,180,200');
  }

//==================================================================
// STANDARD EVENTS
//==================================================================
int OnInit()
  {
   if(InpPivotLen < 1 || InpFastMA < 1 || InpSlowMA < 1 || InpTrendMA < 1 || InpRSIPeriod < 1 || InpATRPeriod < 1)
     {
      Print("SMC Pro: parametrlar noto'g'ri");
      return INIT_PARAMETERS_INCORRECT;
     }
   SetIndexBuffer(0, gFast,  INDICATOR_DATA);
   SetIndexBuffer(1, gSlow,  INDICATOR_DATA);
   SetIndexBuffer(2, gTrend, INDICATOR_DATA);
   SetIndexBuffer(3, gBuy,   INDICATOR_DATA);
   SetIndexBuffer(4, gSell,  INDICATOR_DATA);
   SetIndexBuffer(5, gRsi,   INDICATOR_CALCULATIONS);
   SetIndexBuffer(6, gAtr,   INDICATOR_CALCULATIONS);
   SetIndexBuffer(7, gSig,   INDICATOR_CALCULATIONS);
   SetIndexBuffer(8, gSLb,   INDICATOR_CALCULATIONS);
   SetIndexBuffer(9, gTP1b,  INDICATOR_CALCULATIONS);
   SetIndexBuffer(10, gTP2b, INDICATOR_CALCULATIONS);
   SetIndexBuffer(11, gTP3b, INDICATOR_CALCULATIONS);
   ArraySetAsSeries(gSig, false); ArraySetAsSeries(gSLb, false); ArraySetAsSeries(gTP1b, false);
   ArraySetAsSeries(gTP2b, false); ArraySetAsSeries(gTP3b, false);
   ArraySetAsSeries(gFast, false);  ArraySetAsSeries(gSlow, false); ArraySetAsSeries(gTrend, false);
   ArraySetAsSeries(gBuy, false);   ArraySetAsSeries(gSell, false);
   ArraySetAsSeries(gRsi, false);   ArraySetAsSeries(gAtr, false);

   PlotIndexSetInteger(3, PLOT_ARROW, 233);
   PlotIndexSetInteger(4, PLOT_ARROW, 234);
   for(int k = 0; k < 5; k++)
      PlotIndexSetDouble(k, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpFastMA);
   PlotIndexSetInteger(1, PLOT_DRAW_BEGIN, InpSlowMA);
   PlotIndexSetInteger(2, PLOT_DRAW_BEGIN, InpTrendMA);
   if(!InpShowTrendMA)
      PlotIndexSetInteger(2, PLOT_DRAW_TYPE, DRAW_NONE);
   PlotIndexSetString(0, PLOT_LABEL, StringFormat("Fast MA(%d)", InpFastMA));
   PlotIndexSetString(1, PLOT_LABEL, StringFormat("Slow MA(%d)", InpSlowMA));
   PlotIndexSetString(2, PLOT_LABEL, StringFormat("Trend MA(%d)", InpTrendMA));

   hFast  = iMA(_Symbol, _Period, InpFastMA,  0, InpMAMethod, PRICE_CLOSE);
   hSlow  = iMA(_Symbol, _Period, InpSlowMA,  0, InpMAMethod, PRICE_CLOSE);
   hTrend = iMA(_Symbol, _Period, InpTrendMA, 0, InpMAMethod, PRICE_CLOSE);
   hRsi   = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);
   hAtr   = iATR(_Symbol, _Period, InpATRPeriod);
   if(hFast == INVALID_HANDLE || hSlow == INVALID_HANDLE || hTrend == INVALID_HANDLE ||
      hRsi == INVALID_HANDLE || hAtr == INVALID_HANDLE)
     {
      Print("SMC Pro: indikator handle yaratilmadi, xato ", GetLastError());
      return INIT_FAILED;
     }
   IndicatorSetString(INDICATOR_SHORTNAME, "SMC Structure Pro");
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
   ResetState();
   EventSetTimer(1);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   ObjectsDeleteAll(0, PFX);
   if(hFast  != INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow  != INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hTrend != INVALID_HANDLE) IndicatorRelease(hTrend);
   if(hRsi   != INVALID_HANDLE) IndicatorRelease(hRsi);
   if(hAtr   != INVALID_HANDLE) IndicatorRelease(hAtr);
   ChartRedraw();
  }

void OnTimer()
  {
   string ban = PFX + "D_BAN";
   if(ObjectFind(0, ban) < 0)
      return;
   if(TimeLocal() < g_blinkUntil)
     {
      g_blinkOn = !g_blinkOn;
      ObjectSetInteger(0, ban, OBJPROP_BGCOLOR, g_blinkOn ? g_banBgAlt : g_banBg);
      ChartRedraw();
     }
   else
      if(g_blinkOn)
        {
         g_blinkOn = false;
         ObjectSetInteger(0, ban, OBJPROP_BGCOLOR, g_banBg);
         ChartRedraw();
        }
  }

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int warm = MathMax(MathMax(InpSlowMA, InpTrendMA), MathMax(InpRSIPeriod, InpATRPeriod)) + 2 * InpPivotLen + 5;
   if(rates_total < warm + 10)
      return 0;

   ArraySetAsSeries(time, false);
   ArraySetAsSeries(open, false);
   ArraySetAsSeries(high, false);
   ArraySetAsSeries(low, false);
   ArraySetAsSeries(close, false);

   if(BarsCalculated(hFast) < rates_total || BarsCalculated(hSlow) < rates_total ||
      BarsCalculated(hTrend) < rates_total || BarsCalculated(hRsi) < rates_total ||
      BarsCalculated(hAtr) < rates_total)
      return 0;

   bool full = (prev_calculated <= 0);
   if(!full && (g_lastIdx < 0 || g_lastIdx >= rates_total || time[g_lastIdx] != g_lastTime))
      full = true;

   int count = full ? rates_total : MathMin(rates_total, rates_total - prev_calculated + 2);
   if(!CopyInd(hFast,  rates_total, count, gFast))  return 0;
   if(!CopyInd(hSlow,  rates_total, count, gSlow))  return 0;
   if(!CopyInd(hTrend, rates_total, count, gTrend)) return 0;
   if(!CopyInd(hRsi,   rates_total, count, gRsi))   return 0;
   if(!CopyInd(hAtr,   rates_total, count, gAtr))   return 0;

   if(full)
     {
      if(!InpEAMode) ObjectsDeleteAll(0, PFX);
      ResetState();
      ArrayInitialize(gBuy, EMPTY_VALUE);
      ArrayInitialize(gSell, EMPTY_VALUE);
      ArrayInitialize(gSig, 0); ArrayInitialize(gSLb, 0); ArrayInitialize(gTP1b, 0);
      ArrayInitialize(gTP2b, 0); ArrayInitialize(gTP3b, 0);
      g_lastIdx = MathMax(warm, rates_total - InpHistoryBars) - 1;
     }

   int lastClosed = rates_total - 2;
   for(int i = g_lastIdx + 1; i <= lastClosed; i++)
     {
      g_live = g_ready && (i == lastClosed);
      ProcessBar(i, time, open, high, low, close);
     }
   g_live = false;
   if(lastClosed > g_lastIdx)
     {
      g_lastIdx  = lastClosed;
      g_lastTime = time[lastClosed];
     }
   // shakllanayotgan bar - signal yo'q
   gBuy[rates_total - 1]  = EMPTY_VALUE;
   gSig[rates_total - 1] = 0;
   gSell[rates_total - 1] = EMPTY_VALUE;

   datetime tExt = time[rates_total - 1] + PeriodSeconds() * InpExtendBars;
   ExtendZones(tExt);
   if(g_tr.active)
      DrawTrade(time[rates_total - 1] + PeriodSeconds() * 8);

   DrawDashboard(rates_total, close);
   g_ready = true;
   ChartRedraw();
   return rates_total;
  }
//+------------------------------------------------------------------+
